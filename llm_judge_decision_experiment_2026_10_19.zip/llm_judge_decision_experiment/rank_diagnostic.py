"""Post-hoc exact pairwise rank-margin diagnostic; no inference or tuning.

Projection onto numerical-answer equivalence classes is linear. At most k
response scores can change, so the largest pairwise margin increase is exactly
the sum of the k largest nonnegative cell gains. One relaxation uses the frozen
text library; the other lets every edited raw score take any value in [0,1].
Pairwise overtaking is necessary but not sufficient for winning among three
systems. Negative upper bounds for every challenger certify rank stability.
"""
import json
from pathlib import Path
import numpy as np
from evaluate import load_data,save_csv
from methods import project_scores
ROOT=Path(__file__).resolve().parent

def main():
    data=load_data();cube=data['test']['cube'];raw=cube[0];ans=data['test']['answers']
    n,k=raw.shape;cap=int(.1*raw.size);best=int(data['test']['Y'].mean(0).argmax())
    rows=[];witnesses={}
    for mode in ['raw_judge','answer_consistent_judge']:
        scores=raw if mode=='raw_judge' else project_scores(raw,ans)
        for j in range(k):
            if j==best:continue
            coeff=np.zeros_like(raw)
            if mode=='raw_judge':coeff[:,j]=1/n;coeff[:,best]=-1/n
            else:
                for i in range(n):
                    for value in np.unique(ans[i]):
                        group=ans[i]==value
                        if value!='None':coeff[i,group]=(int(group[j])-int(group[best]))/(group.sum()*n)
            base=float(scores[:,j].mean()-scores[:,best].mean())
            np.testing.assert_allclose(np.sum(coeff*raw),base,atol=1e-12)
            cell_variants=coeff[None,:,:]*(cube-raw[None,:,:])
            library_gain=cell_variants.max(axis=0)
            relaxed_gain=np.maximum(coeff*(np.where(coeff>0,1.0,0.0)-raw),0)
            for kind,gain in [('frozen_text_library',library_gain),('any_score_in_unit_interval',relaxed_gain)]:
                order=np.argsort(gain.ravel(),kind='stable')[::-1]
                cumulative=np.cumsum(gain.ravel()[order]);hit=np.flatnonzero(base+cumulative>=0)
                row={'mode':mode,'challenger':data['systems'][j],'best_true_system':data['systems'][best],
                     'attack_relaxation':kind,'clean_pairwise_margin':base,'edit_cap':cap,
                     'largest_margin_at_cap':float(base+cumulative[cap-1]),
                     'minimum_edits_for_pairwise_tie':int(hit[0]+1) if len(hit) else None,
                     'cannot_overtake_at_cap':bool(base+cumulative[cap-1]<0)}
                rows.append(row)
                if kind=='frozen_text_library':
                    mask=np.zeros_like(raw,int);ix=order[:cap]
                    mask.ravel()[ix]=cell_variants.argmax(axis=0).ravel()[ix]
                    attacked=cube[mask,np.arange(n)[:,None],np.arange(k)[None,:]]
                    if mode!='raw_judge':attacked=project_scores(attacked,ans)
                    np.testing.assert_allclose(attacked[:,j].mean()-attacked[:,best].mean(),row['largest_margin_at_cap'],atol=1e-12)
                    witnesses[mode+':'+str(j)]={'mask':mask.tolist(),'selected_system':data['systems'][attacked.mean(0).argmax()]}
    save_csv(ROOT/'rank_margin_diagnostic.csv',rows)
    (ROOT/'rank_margin_witnesses.json').write_text(json.dumps(witnesses,indent=2)+'\n')
    print(json.dumps(rows,indent=2))

if __name__=='__main__':main()
