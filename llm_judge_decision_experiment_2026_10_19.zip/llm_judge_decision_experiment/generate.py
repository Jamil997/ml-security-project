"""Append-only generation; test requires a frozen development choice."""
import argparse
import hashlib
import json
import re
import time
from decimal import Decimal, InvalidOperation
from pathlib import Path

import mlx.core as mx
from mlx_lm import load, stream_generate
from mlx_lm.sample_utils import make_sampler

ROOT = Path(__file__).resolve().parent


def number(text):
    try:
        return Decimal(text.replace(",", "").replace("$", "").strip())
    except InvalidOperation:
        return None


def extract(text):
    matches = re.findall(r"(?im)^\s*(?:\*\*)?Final answer\s*:\s*(?:\*\*)?\s*\$?\s*(-?[0-9][0-9,]*(?:\.[0-9]+)?)", text)
    return number(matches[-1]) if len(matches) == 1 else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--split", choices=["development", "calibration", "test"], required=True)
    ap.add_argument("--questions", type=int)
    ap.add_argument("--model-dir", help="Optional local model path; does not change frozen prompts or decoding")
    args = ap.parse_args()
    p = json.loads((ROOT / "protocol.json").read_text())
    if args.split != "development":
        assert (ROOT / "frozen_systems.json").exists(), "Freeze incumbent before further data"
    rows = [json.loads(line) for line in (ROOT / "questions.jsonl").read_text().splitlines()]
    rows = [r for r in rows if r["split"] == args.split]
    if args.questions:
        rows = rows[:args.questions]
    out = ROOT / "generations.jsonl"
    done = set()
    if out.exists():
        done = {r["id"] for r in map(json.loads, out.read_text().splitlines())}
    start = time.perf_counter()
    model, tokenizer = load(str(Path(args.model_dir).resolve() if args.model_dir else (ROOT / p["model_path"]).resolve()))
    sampler = make_sampler(temp=0)
    completed = 0
    with out.open("a", buffering=1) as f:
        for row in rows:
            for system in p["systems"]:
                rid = row["id"] + ":" + system["id"]
                if rid in done:
                    continue
                content = system["instruction"] + "\n\nProblem:\n" + row["question"]
                prompt = tokenizer.apply_chat_template([{"role": "user", "content": content}], tokenize=False, add_generation_prompt=True)
                ids = tokenizer.encode(prompt, add_special_tokens=False)
                begin = time.perf_counter()
                text, tokens = "", []
                for response in stream_generate(model, tokenizer, ids, max_tokens=system["max_tokens"], sampler=sampler):
                    text += response.text
                    tokens.append(response.token)
                predicted = extract(text)
                record = {"id": rid, "question_id": row["id"], "split": row["split"], "system": system["id"],
                          "text": text, "token_ids": tokens, "prompt_sha256": hashlib.sha256(prompt.encode()).hexdigest(),
                          "prompt_tokens": len(ids), "generated_tokens": len(tokens),
                          "parsed_answer": str(predicted) if predicted is not None else None,
                          "correct": predicted is not None and predicted == number(row["gold"]),
                          "seconds": time.perf_counter() - begin, "peak_memory_gb": response.peak_memory,
                          "hit_token_cap": len(tokens) == system["max_tokens"]}
                f.write(json.dumps(record) + "\n")
                completed += 1
            print(json.dumps({"split": args.split, "last_question": row["id"], "new_generations": completed,
                              "elapsed_seconds": round(time.perf_counter()-start, 3)}), flush=True)
    print(json.dumps({"status": "complete", "new_generations": completed, "seconds": time.perf_counter()-start}), flush=True)


if __name__ == "__main__":
    main()
