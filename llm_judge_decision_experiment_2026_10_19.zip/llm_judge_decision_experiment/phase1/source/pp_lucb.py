"""Ao et al. Algorithm 1, equations 6--14, on a cached empirical population.

Arms are frozen generators. Contexts are iid draws with replacement from the
test pool. Repeated observations are charged under the paper's per-observation
cost model; unique labels are also counted. Bounded-budget fallback and an
incumbent-only stopping adapter are explicitly reported alongside full BAI.
"""
import numpy as np


def psi(v,alpha):
    # Published log(log(2v)) is undefined at small v; flooring to one widens
    # the boundary instead of silently assigning zero confidence width.
    v=np.maximum(v,1.0)
    return 1.7*np.sqrt(v*(np.log(np.log(2*v))+0.72*np.log(5.2/alpha)))


def run(proxy,labels,cal_proxy,cal_labels,cost_cap,rho,audit_rate,sims,seed,alpha=0.01,safe_update=False):
    rng=np.random.default_rng(seed);N,K=proxy.shape
    cal_cost=cal_labels.size*rho+cal_proxy.size
    choices=np.zeros(sims,dtype=int);costs=np.full(sims,float(cal_cost))
    counts=np.zeros((sims,K));sumF=np.zeros_like(counts);sumR=np.zeros_like(counts);sumR2=np.zeros_like(counts)
    audit_counts=np.zeros(sims);unique=np.zeros((sims,N,K),bool)
    bins=np.minimum((proxy*5).astype(int),4)
    cbins=np.minimum((cal_proxy*5).astype(int),4)
    ss=np.zeros((K,5));nn=np.zeros((K,5))
    for k in range(K):
        rr=(cal_labels[:,k]-cal_proxy[:,k])**2
        for b in range(5):
            mask=cbins[:,k]==b;nn[k,b]=mask.sum()+5;ss[k,b]=rr[mask].sum()+5*rr.mean()
    sums=np.repeat(ss[None,:,:],sims,axis=0);nums=np.repeat(nn[None,:,:],sims,axis=0)
    # Only paid calibration scores and subsequently queried scores may estimate
    # the proxy distribution. The unqueried full test score histogram is not free.
    prior_hist=np.array([np.bincount(cbins[:,k],minlength=5)+1 for k in range(K)],dtype=float)
    hist=np.repeat(prior_hist[None,:,:],sims,axis=0)
    alive=costs+(1+rho)<=cost_cap
    indices=np.arange(sims);delta=alpha/K;steps=0
    while np.any(alive):
        den=np.maximum(counts,1)
        means=(sumF+sumR)/den
        width=(psi(counts/4,delta/2)+psi(sumR2,delta/2)+0.45*(2/0.05)*np.log(10.4/delta))/den
        lo,hi=means-width,means+width
        lo[counts<4]=-np.inf;hi[counts<4]=np.inf
        best=means.argmax(axis=1)
        other=hi.copy();other[indices,best]=-np.inf;challenger=other.argmax(axis=1)
        if safe_update:
            margins=lo-hi[:,[0]];margins[:,0]=-np.inf
            proposed=margins.argmax(axis=1);stop=np.max(margins,axis=1)>0
        else:
            proposed=best;stop=lo[indices,best]>other.max(axis=1)
        stop&=alive;choices[stop]=proposed[stop];alive[stop]=False
        if not np.any(alive):break
        # Initialize each arm, then perform the paper's best/challenger pulls.
        selected=[np.full(sims,steps,dtype=int)] if steps<K else [best,challenger]
        for arm in selected:
            ids=np.flatnonzero(alive)
            if not len(ids):break
            aa=arm[ids];ctx=rng.integers(0,N,size=len(ids));bb=bins[ctx,aa]
            scores=proxy[ctx,aa]
            hist[ids,aa,bb]+=1
            st=np.sqrt(np.maximum(sums[ids,aa]/nums[ids,aa],1e-6))
            ff=hist[ids,aa];ff=ff/ff.sum(axis=1,keepdims=True)
            low=np.zeros(len(ids));high=np.full(len(ids),1000.0)
            for _ in range(16):
                mid=(low+high)/2
                rate=(np.clip(mid[:,None]*st,0.05,1)*ff).sum(axis=1)
                take=rate<audit_rate;low=np.where(take,mid,low);high=np.where(take,high,mid)
            prob=np.clip(((low+high)/2)*st[np.arange(len(ids)),bb],0.05,1)
            audited=rng.random(len(ids))<prob
            # Only audited labels enter statistics and online variance updates.
            residual=np.zeros(len(ids));audit_ids=np.flatnonzero(audited)
            raw=labels[ctx[audit_ids],aa[audit_ids]]-scores[audit_ids]
            residual[audit_ids]=raw/prob[audit_ids]
            sumF[ids,aa]+=scores;sumR[ids,aa]+=residual;sumR2[ids,aa]+=residual**2;counts[ids,aa]+=1
            sums[ids[audit_ids],aa[audit_ids],bb[audit_ids]]+=raw**2
            nums[ids[audit_ids],aa[audit_ids],bb[audit_ids]]+=1
            unique[ids[audit_ids],ctx[audit_ids],aa[audit_ids]]=True
            costs[ids]+=1+rho*audited;audit_counts[ids]+=audited
            alive&=costs+(1+rho)<=cost_cap
        steps+=1
        assert steps<100000,'Unexpected cost-loop failure'
    return choices,{'cost':costs,'audit_labels':audit_counts+cal_labels.size,
                    'unique_test_labels':unique.sum(axis=(1,2)),
                    'judge_queries':counts.sum(axis=1)+cal_proxy.size,'iterations':steps,
                    'safe_update_adapter':safe_update}
