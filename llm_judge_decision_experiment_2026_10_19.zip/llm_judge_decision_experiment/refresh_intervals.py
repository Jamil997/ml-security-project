"""Account jointly for the primary 378 rows and exploratory 126 stress rows."""
import json
from pathlib import Path
import numpy as np
from evaluate import load_data,interval,save_csv
ROOT=Path(__file__).resolve().parent

def main():
    data=load_data()
    for folder,fraction,expected in [(ROOT,.1,126),(ROOT/'stress_15_percent',.15,42)]:
        files=list((folder/'evaluation').glob('*.json'));assert len(files)==expected
        allrows=[]
        for file in files:
            r=json.loads(file.read_text());saved=np.load(file.with_suffix('.npz'))
            for row in r['rows']:
                row.update(interval(saved[row['scenario']+'_choices'],data['test']['Y'],family=504))
                row['attack_fraction']=fraction
            file.write_text(json.dumps(r,indent=2)+'\n');allrows+=r['rows']
        save_csv(folder/'results.csv',allrows)
    print('Simultaneous Monte Carlo intervals refreshed across all 504 final rows; first-pass exploratory results preserved separately.')

if __name__=='__main__':main()
