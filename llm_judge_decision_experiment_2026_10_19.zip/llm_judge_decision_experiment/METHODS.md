# Audited system selection with an attacked language-model judge

The decision is whether to replace a frozen incumbent with another frozen system. A system is a prompting configuration of Mistral, not a separately trained model. For each question, all three responses are available. This experiment isolates evaluation and selection; it does not yet study the missing action outcomes or logging-probability variance in the OptDigits experiments.

## Target and information

Let \(i\in\{1,\ldots,N\}\) index questions and \(j\in\{0,1,2\}\) index systems, with \(j=0\) the incumbent. The reference label \(Y_{ij}\in\{0,1\}\) records whether the final numerical answer equals the benchmark answer. The judge supplies a score \(S_{ij}\in[0,1]\), which need not be calibrated or unbiased. The finite-pool accuracy and improvement are

\[
V_j=N^{-1}\sum_iY_{ij},\qquad \Delta_j=V_j-V_0.
\]

The output \(\widehat j\) may be the incumbent. We measure expected improvement \(U=\mathbb E[\Delta_{\widehat j}]\), harmful deployment \(H=\Pr(\Delta_{\widehat j}<0)\), and total evaluation cost \(C\). Expectations here concern the procedure's private audit randomness on a fixed question pool. The reference labels are available to the evaluator but enter the selection procedure only when an audit is purchased. Invalid final answers count as incorrect by the declared task definition. Identical numerical answers have identical correctness; every method can use this information without purchasing a label.

GSM8K references act as a simulated trustworthy oracle. No human annotators were hired. The experiment charges hypothetical audit costs to study when verification would be worth paying for. Correct final answers do not certify correct reasoning, absence of prompt injection, or general response quality.

## Residual correction and its connection to prior work

Write \(D_{ij}=Y_{ij}-Y_{i0}\) and \(P_{ij}=S_{ij}-S_{i0}\). A question-level audit \(A_i\sim\operatorname{Bernoulli}(p_i)\) reveals the three labels. Its probability is chosen from observable responses, judge scores, and, where used, a separate charged calibration set. For a coefficient \(\beta\), the paired prediction-powered estimate is

\[
\widehat\Delta_j=\frac1N\sum_i\left[\beta P_{ij}
 +\frac{A_i}{p_i}(D_{ij}-\beta P_{ij})\right].
\]

Conditional on the fixed labels and attacked scores, independent audit coins give \(\mathbb E[A_i/p_i]=1\). Thus the estimate is unbiased even if the judge is biased or attacked. The corresponding conditional variance is

\[
\operatorname{Var}(\widehat\Delta_j)=\frac1{N^2}\sum_i
 \frac{1-p_i}{p_i}(D_{ij}-\beta P_{ij})^2.
\]

This identifies the useful role of a judge: it should reduce the residual variance enough to pay for its calls and calibration. Merely making its scores larger does not establish that benefit. An unbiased estimate also does not automatically give a valid small-sample confidence interval.

[Active Statistical Inference](https://proceedings.mlr.press/v235/zrnic24a.html) develops selective label collection around prediction-powered correction. [PPI++](https://arxiv.org/abs/2311.01453) already establishes tuning the prediction coefficient; coefficient shrinkage is not a new contribution here. Our experimental joint rule combines a small coefficient grid, a calibrated residual model, and a decision-weighted audit objective. This combination needs comparison and analysis before it could support a novelty claim.

[Robust Sampling](https://arxiv.org/abs/2511.08991) protects active allocation against misspecified uncertainty estimates. We implement its geometric interpolation between active and uniform allocation and its L2 uncertainty objective. If \(g_i\) predicts squared residual size, our single-contrast objective is

\[
\frac1N\sum_i\frac{g_i}{p_i}
 +c\sqrt{\frac1N\sum_i p_i^{-2}},\qquad
\frac1N\sum_i p_i=b.
\]

The closed-form objective was checked against the released implementation. Binned regression, shared question-level audits, a finite interpolation grid, and re-normalization after clipping are documented task adaptations. The implementation does not reproduce all experiments or inherit asymptotic guarantees at this sample size.

The residual-based methods deploy the candidate with the largest positive lower bound; otherwise they retain the incumbent. Their normal intervals are asymptotic comparators. The experiment reports their observed harmful deployment separately from the finite-pool guarantees below.

## Exact finite-pool alternative

The exact trusted comparators sample questions uniformly, either from the whole pool or from questions where answers disagree. The judge-stratified alternative partitions the disagreement pool by the system with the highest projected judge score and allocates a fixed audit budget across these groups. Within each group, the final sample is uniformly random and private.

A stronger practical comparator first chooses the highest-ranked challenger using the frozen development ranking. It then audits only that challenger and the incumbent, paying for two labels per sampled question. Answer agreement identifies zero differences for free. Because this choice uses independent development data, its exact test needs one candidate contrast rather than two. This is an available strategy for exploiting development evidence, not an oracle that selects the best test system.

For every candidate, partition, and sign of the correctness difference, we invert the hypergeometric distribution to bound the number of positive or negative differences remaining in the pool. Simultaneous bounds use a failure allocation of \(\alpha/(4G)\), where \(G\) is the number of nonempty groups and there are two candidate contrasts. Known zero differences and missing final answers reduce the possible supports for every comparator. Dividing the lower positive-count bound minus the upper negative-count bound by \(N\), and summing over groups, yields \(L_j\). Deploying only when \(L_j>0\) controls harmful selection on the fixed pool.

The key assumption is timing: the attacker commits before the defender draws its private audits. The partition may be misleading, but uniform sampling within the committed groups remains valid. An attack can still destroy efficiency by sending the audits to unhelpful groups. This is a standard stratified-inference construction, not evidence that we invented a new confidence bound.

## Why the original corruption budget cannot test harmful judge selection

Let \(\overline S_j\) denote the mean judge score after answer-consistency projection, and let \(b\) be its clean winner. Altering one raw response score in \([0,1]\) changes a pairwise mean difference by at most \(1/N\). Averaging within an answer-equivalence class can only reduce that coefficient. Consequently,

\[
\overline S_b^{\rm attacked}-\overline S_j^{\rm attacked}
\geq \overline S_b-\overline S_j-\frac{k}{N}.
\]

In this dataset, the winner's score margin is approximately 0.253 over the incumbent and 0.375 over the inferior system. With \(N=300\), a ranking change therefore needs at least 76 or 113 response edits, respectively. The exact unrounded margins are saved in `rank_margin_diagnostic.csv`. Top-cell optimization and a small integer program construct actual text-library witnesses achieving these lower bounds. Replaying the selected suffixes confirms the intended winning system.

The primary cap is 90 edits. Its inability to make the projected judge choose the inferior system follows from the margin bound, independently of an audit defense. The exploratory cap of 135 exceeds the harmful-selection threshold. This calculation concerns the judge's ranking on the fixed pool. A stable judge ranking does not generally certify correctness or true system quality; their relationship here is measured using the held-out reference labels.

## Sequential comparator

[Ao et al.](https://arxiv.org/html/2601.21471v1) combine residual correction, adaptive auditing, and confidence sequences for best-arm identification. Our PP-LUCB adapter follows the published estimator, confidence widths, best/challenger sampling, and binned Neyman updates. It samples with replacement from the empirical question population and charges each observation under the paper's cost model. A second adapter stops once a candidate is certified better than the incumbent. Both retain the incumbent when the fixed cost budget expires without a certificate.

These sequential methods can purchase individual labels; the paired methods purchase three-label bundles. Repeated observations are charged in the sequential adapter even when their underlying cached question repeats. This reproduces a per-observation cost convention, but differs from a finite-pool method that can cache a purchased label permanently. Poor performance of this adapter would therefore motivate a better finite-pool implementation, not a claim against the published general method. The positive minimum audit probability is 0.05. Its range-dependent confidence term can be conservative at the budgets studied here.

In the completed experiment, both PP-LUCB adapters exhausted their budgets while retaining the incumbent. Their repeated-observation convention and range-dependent confidence term are material to that result. A finite-pool implementation with reusable audits and stronger tuning is necessary before drawing conclusions about the published method's practical efficiency.

## Text attacks and trust assumptions

The attacker is **black-box with respect to judge weights and white-box with respect to the selection procedure**. It can append at most 128 tokens to at most 90 of the 900 test responses. The numerical answer must remain unchanged under the frozen parser. It cannot alter the benchmark references, frozen generators, independent calibration data, or future audit coins.

The attack library contains simple instructions, role-boundary strings, compositions, and two released JudgeDeceiver suffixes. Development-only black-box scoring selects a small transferable library. On the test pool, a strong attacker may know the reference labels when placing suffixes. It searches separately for low selected-system improvement and high harmful deployment using 128 audit replications; final evaluation uses 5,000 independent audit replications. The search is heuristic and provides feasible attack witnesses, not exhaustive worst-case optimization.

[Shi et al.](https://arxiv.org/abs/2403.17710) optimize text that manipulates an LLM judge. This experiment extends the measured outcome from judge verdict changes to the downstream decision about which system to deploy. It uses transferred suffixes and bounded black-box search, not a reproduction of the authors' gradient attack. Every reported corrupted score is produced by the real frozen judge on an actual modified response.

## Cost and inference limits

One judge call costs one unit. A trusted response label costs \(\rho\in\{5,20,50\}\) units. Calibrated methods pay for all 180 calibration labels and their 180 judge calls. Trusted-only methods can spend the money saved on extra labels. Development and initial response generation are shared setup costs; they are recorded but excluded from the marginal evaluation comparison. Different deployment-time generation costs are outside this pilot's utility target.

Bernoulli auditing uses an expected budget and reports realized cost, including occasional overspending. Exact fixed-size methods and the sequential cost cap use hard budgets. These are distinct operational constraints and must not be conflated.

Monte Carlo intervals are simultaneous across the planned configurations, but conditional on this pool and these searched attacks. Question-bootstrap intervals describe a separate source of uncertainty. A point on the measured frontier is not a proof of global Pareto optimality. At a fixed harm ceiling, a defensible efficiency claim requires better improvement at no higher total cost, or lower cost for the same improvement, against strong feasible comparators. An exact risk guarantee and an empirical mean advantage are different pieces of evidence.
