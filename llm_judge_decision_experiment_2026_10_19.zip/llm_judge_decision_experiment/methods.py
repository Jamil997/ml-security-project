"""Auditing and selection rules. No method may access unqueried test labels.

For efficient Monte Carlo the simulator supplies labels *after* constructing
the sampling plan. Plan functions accept proxy/answer features and calibration
data only. Conditional finite-pool and asymptotic intervals are distinguished.
"""
from functools import lru_cache
from decimal import Decimal
import numpy as np
from scipy.special import ndtr
from scipy.stats import hypergeom, norm

_CAL_CACHE = {}


def answer_key(value):
    """Numerical equivalence includes 4, 4.0, and 4.00; no oracle is needed."""
    if value is None:return 'None'
    number=Decimal(str(value))
    return '0' if number==0 else format(number.normalize(),'f')


def project_scores(proxy,answers):
    """Give every judge-based method the same verifiable answer information.

    Missing operational final answers are known incorrect; equal numeric answers
    have equal correctness. These statements use no reference answer. Average
    proxy scores within equality classes *after* a mixed text attack is applied.
    """
    result=np.asarray(proxy,dtype=float).copy()
    for i in range(len(result)):
        for value in np.unique(answers[i]):
            mask=answers[i]==value
            result[i,mask]=0.0 if value=='None' else result[i,mask].mean()
    return result


def normalize(weights, budget, floor=0.05):
    weights=np.maximum(np.asarray(weights,dtype=float),1e-8)
    if budget>=1:return np.ones_like(weights)
    if budget<=floor:return np.full_like(weights,budget)
    lo,hi=0.0,1.0
    while np.minimum(1,np.maximum(floor,hi*weights)).mean()<budget:hi*=2
    for _ in range(45):
        mid=(lo+hi)/2
        if np.minimum(1,np.maximum(floor,mid*weights)).mean()<budget:lo=mid
        else:hi=mid
    return np.minimum(1,np.maximum(floor,(lo+hi)/2*weights))


def differences(x):
    return x[:,1:]-x[:,[0]]


def fit_errors(proxy,labels,beta=1.0):
    x=differences(proxy);r=(differences(labels)-beta*x)**2
    cuts=np.array([-0.5,0,0.5]);models=[]
    for j in range(x.shape[1]):
        bins=np.digitize(x[:,j],cuts);global_mean=r[:,j].mean()
        models.append(np.array([(r[bins==b,j].sum()+5*global_mean)/(np.sum(bins==b)+5) for b in range(4)]))
    return np.array(models)


def predict_errors(model,proxy):
    x=differences(proxy);bins=np.digitize(x,[-0.5,0,0.5])
    return np.maximum(np.stack([model[j,bins[:,j]] for j in range(x.shape[1])],axis=1),1e-6)


def geometric_plan(g,budget,c=0.0,gaps=None):
    """Li et al. Eq.4 with L2 radius c*sqrt(n), geometric path.

    Budget-normalization is repeated after clipping. Upstream clips a normalized
    path without renormalizing, which can underspend; our accounting fixes this.
    A trace objective allocates shared audit bundles across two contrasts.
    """
    if budget>=1:return np.ones(len(g)),{'rho':1.0,'objective':0.0}
    scale=np.ones(g.shape[1]) if gaps is None else np.maximum(np.abs(gaps),0.05)**2
    base=normalize(np.sqrt(np.mean(g/scale,axis=1)),budget)
    best=None
    for rho in np.linspace(0,1,21):
        p=normalize(base**(1-rho)*budget**rho,budget)
        # Closed-form support function of an l2 uncertainty ball.
        vals=np.mean(g/p[:,None],axis=0)/scale
        penalty=c*np.sqrt(np.mean(1/p**2))
        objective=float(np.mean(vals)+penalty) if gaps is None else float(np.max(vals)+penalty)
        if best is None or objective<best[0]-1e-12:best=(objective,p,rho)
    return best[1],{'rho':float(best[2]),'objective':best[0]}


def tune_calibration(proxy,labels,budget):
    """Five-fold independent calibration; tune robustness using held-out residuals.

    This implements the published l2 minimax/CV structure, with a binned error
    model instead of upstream's neural nets. Finite n=60 does not confer its
    asymptotic efficiency guarantee.
    """
    cgrid=[0,0.01,0.03,0.1,0.3,1.0]
    scores=[]
    for c in cgrid:
        v=0.0
        for fold in range(5):
            valid=np.arange(len(proxy))%5==fold
            g=predict_errors(fit_errors(proxy[~valid],labels[~valid]),proxy[valid])
            p,_=geometric_plan(g,budget,c)
            residual=differences(labels[valid])-differences(proxy[valid])
            v+=float(np.mean(residual**2*(1/p[:,None]-1)))
        scores.append(v)
    return float(cgrid[int(np.argmin(scores))])


def make_plan(name,proxy,budget,cal_proxy=None,cal_labels=None):
    n=len(proxy)
    if name=='ppi_uniform':return np.full(n,budget),1.0,{}
    if name=='power_tuned_uniform':
        # Strong ablation: use the same charged calibration and coefficient
        # grid as the joint rule, but purchase uniform audits. On this finite
        # pool, Poisson-audit variance depends on the residual second moment.
        pred=differences(cal_proxy);truth=differences(cal_labels)
        grid=[0,0.25,0.5,0.75,1.0]
        values=[np.mean((truth-beta*pred)**2) for beta in grid]
        coefficient=float(grid[int(np.argmin(values))])
        return np.full(n,budget),coefficient,{'calibrated_second_moment':float(min(values))}
    if name=='asi_uncertainty':
        uncertainty=np.sqrt(np.mean(proxy*(1-proxy),axis=1))
        return normalize(uncertainty,budget),1.0,{}
    if name=='robust_asi_l2':
        key=(name,round(float(budget),10),cal_proxy.tobytes(),cal_labels.tobytes())
        if key not in _CAL_CACHE:_CAL_CACHE[key]=tune_calibration(cal_proxy,cal_labels,budget)
        c=_CAL_CACHE[key]
        g=predict_errors(fit_errors(cal_proxy,cal_labels),proxy)
        p,meta=geometric_plan(g,budget,c)
        return p,1.0,{**meta,'c':c}
    if name=='joint_proxy_shrinkage':
        # Calibration chooses BOTH the proxy coefficient and decision-weighted
        # sampling. Beta=0 and uniform are eligible. This is an experimental
        # combination of power tuning and robust active inference, not a theorem.
        gaps=differences(cal_labels).mean(axis=0)
        key=(name,round(float(budget),10),cal_proxy.tobytes(),cal_labels.tobytes())
        best=_CAL_CACHE.get(key)
        for beta in ([] if best is not None else [0,0.25,0.5,0.75,1.0]):
            # Tune shrinkage on held-out folds, not on evaluation labels.
            cv=0.0
            for fold in range(5):
                val=np.arange(len(cal_proxy))%5==fold
                g=predict_errors(fit_errors(cal_proxy[~val],cal_labels[~val],beta),cal_proxy[val])
                pp,_=geometric_plan(g,budget,0.1,gaps)
                rr=differences(cal_labels[val])-beta*differences(cal_proxy[val])
                cv+=float(np.max(np.mean(rr**2*(1/pp[:,None]-1),axis=0)/np.maximum(np.abs(gaps),0.05)**2))
            if best is None or cv<best[0]-1e-12:best=(cv,beta)
        _CAL_CACHE[key]=best
        beta=best[1]
        g=predict_errors(fit_errors(cal_proxy,cal_labels,beta),proxy)
        p,meta=geometric_plan(g,budget,0.1,gaps)
        return p,beta,{**meta,'beta':beta,'calibration_cv':best[0]}
    raise ValueError(name)


def normal_decisions(proxy,labels,p,beta,coins,alpha=0.01):
    """Paired finite-pool AIPW estimate and asymptotic normal interval.

    Unobserved labels are zeroed before accumulation; missing outcomes cannot
    affect the estimate, variance or selected index. Variance is unbiased for
    conditional audit variance, but its Wald interval has no finite-n guarantee.
    """
    n=len(proxy);sampled=coins<p[None,:]
    diff=differences(labels);pred=beta*differences(proxy)
    residual=diff-pred
    est=pred.mean(axis=0)[None,:]+(sampled/p[None,:])@residual/n
    var=(sampled*(1-p)[None,:]/p[None,:]**2)@(residual**2)/n**2
    lower=est-norm.ppf(1-alpha/2)*np.sqrt(np.maximum(var,0))
    scores=np.column_stack([np.zeros(len(coins)),lower])
    choice=scores.argmax(axis=1)
    return choice,sampled.sum(axis=1),lower


@lru_cache(maxsize=20000)
def hypergeom_bounds(N,m,alpha):
    """Exact one-sided inversion for a binary finite-population total."""
    if m==0:return np.array([0]),np.array([N])
    if m==N:return np.arange(N+1),np.arange(N+1)
    lower=np.empty(m+1,dtype=int);upper=np.empty(m+1,dtype=int)
    allK=np.arange(N+1)
    for x in range(m+1):
        feasible=(allK>=x)&(allK<=N-m+x)
        lgood=feasible&(hypergeom.sf(x-1,N,allK,m)>alpha)
        ugood=feasible&(hypergeom.cdf(x,N,allK,m)>alpha)
        lower[x]=allK[lgood][0];upper[x]=allK[ugood][-1]
    return lower,upper


def allocate_counts(sizes,weights,total):
    sizes=np.asarray(sizes,int);total=min(int(total),int(sizes.sum()))
    if total>=sizes.sum():return sizes.copy()
    counts=np.zeros_like(sizes)
    for _ in range(total):
        priorities=np.where(counts<sizes,weights*sizes/(counts+1),-np.inf)
        counts[int(np.argmax(priorities))]+=1
    return counts


def exact_plan(name,proxy,answers,total):
    n=len(proxy)
    # Equality of parsed numerical answers implies equal correctness under the
    # predeclared grading target. This feature needs no oracle and is available
    # to BOTH trusted-only and proposed audit designs.
    same=np.all(answers==answers[:,[0]],axis=1)
    if name=='trusted_uniform':groups=[np.arange(n)];weights=np.ones(1)
    elif name=='trusted_disagreement':groups=[np.flatnonzero(~same)];weights=np.ones(1)
    elif name=='exact_stratified':
        winners=proxy.argmax(axis=1)
        groups=[np.flatnonzero((~same)&(winners==j)) for j in range(proxy.shape[1])]
        groups=[g for g in groups if len(g)]
        weights=np.array([0.25+np.sqrt(np.mean(proxy[g]*(1-proxy[g]))) for g in groups])
    else:raise ValueError(name)
    groups=[g for g in groups if len(g)]
    if not groups:return [],np.array([],int)
    counts=allocate_counts([len(g) for g in groups],weights,total)
    return groups,counts


def exact_decisions(proxy,labels,answers,total,keys,name,alpha=0.01):
    groups,counts=exact_plan(name,proxy,answers,total)
    sims=len(keys);n=len(labels);lower=np.zeros((sims,2))
    diff=differences(labels)
    if not groups:return np.zeros(sims,int),np.zeros(sims),lower
    level=alpha/(4*len(groups))
    for group,m in zip(groups,counts):
        order=np.argsort(keys[:,group],axis=1)[:,:m]
        sample=group[order]
        for j in range(2):
            # Answer equality reveals a zero *difference*, without revealing
            # either correctness label. Apply this fact to every comparator.
            for sign,arm in [(1,j+1),(-1,0)]:
                eligible=(answers[group,j+1]!=answers[group,0])&(answers[group,arm]!='None')
                population=int(eligible.sum())
                if population==0:continue
                observed=((answers[sample,j+1]!=answers[sample,0])&(answers[sample,arm]!='None')).sum(axis=1)
                successes=(sign*diff[sample,j]>0).sum(axis=1)
                for m_observed in np.unique(observed):
                    use=observed==m_observed
                    lo,hi=hypergeom_bounds(population,int(m_observed),level)
                    bound=lo[successes[use]] if sign==1 else hi[successes[use]]
                    lower[use,j]+=sign*bound/n
    chosen=np.column_stack([np.zeros(sims),lower]).argmax(axis=1)
    return chosen,np.full(sims,counts.sum()),lower


def trusted_challenger(labels,answers,total,keys,challenger,alpha=0.01):
    """One development-selected challenger; two purchased labels per audit.

    Preselecting on independent development data costs no additional test alpha.
    The private sample focuses on unequal answers; each sign gets alpha/2.
    """
    n=len(labels);sims=len(keys);j=challenger
    group=np.flatnonzero(answers[:,j]!=answers[:,0]);m=min(total,len(group))
    if not len(group):return np.zeros(sims,int),np.zeros(sims),np.zeros(sims)
    sample=group[np.argsort(keys[:,group],axis=1)[:,:m]]
    diff=labels[:,j]-labels[:,0];lower=np.zeros(sims)
    for sign,arm in [(1,j),(-1,0)]:
        population=int(np.sum(answers[group,arm]!='None'))
        if not population:continue
        observed=(answers[sample,arm]!='None').sum(axis=1)
        successes=(sign*diff[sample]>0).sum(axis=1)
        for mm in np.unique(observed):
            use=observed==mm;lo,hi=hypergeom_bounds(population,int(mm),alpha/2)
            lower[use]+=sign*(lo[successes[use]] if sign==1 else hi[successes[use]])/n
    return np.where(lower>0,j,0),np.full(sims,m),lower


def summary(choice,labels,incumbent=0):
    values=labels.mean(axis=0);gains=values-values[incumbent]
    selected=gains[choice]
    return {'utility':float(selected.mean()),'harm':float(np.mean(selected<0)),
            'update_rate':float(np.mean(choice!=incumbent)),
            'optimal_selection_rate':float(np.mean(choice==values.argmax()))}
