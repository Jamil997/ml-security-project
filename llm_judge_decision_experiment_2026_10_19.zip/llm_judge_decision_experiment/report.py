"""Summarize the frozen experiment without selecting favorable cost settings."""
import csv
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import beta
from evaluate import load_data,apply_attack,save_csv
from methods import project_scores

ROOT=Path(__file__).resolve().parent
LABELS={'retain':'Retain incumbent','judge_only':'Judge only','trusted_uniform':'Trusted uniform',
 'development_only':'Development winner, no new audit',
 'trusted_disagreement':'Trusted disagreement','ppi_uniform':'PPI uniform (Wald)',
 'trusted_dev_challenger':'Trusted development challenger',
 'power_tuned_uniform':'Power-tuned uniform (Wald)',
 'asi_uncertainty':'ASI uncertainty (Wald)','robust_asi_l2':'Robust ASI adapter (Wald)',
 'joint_proxy_shrinkage':'Joint shrinkage (Wald)','exact_stratified':'Exact judge strata',
 'pp_lucb':'PP-LUCB adapter','pp_lucb_safe':'PP-LUCB safe-update adapter'}

def number(x):
    return f'{float(x):.3f}'.rstrip('0').rstrip('.') if float(x)!=0 else '0'

def percent(x):return number(100*float(x))+'%'

def read_csv(path):
    result=[]
    for r in csv.DictReader(path.open()):
        for k,v in r.items():
            try:r[k]=float(v)
            except (ValueError,TypeError):pass
        result.append(r)
    return result

def table(rows,columns):
    return '\n'.join(['| '+' | '.join(a for a,b in columns)+' |',
      '| '+' | '.join('---' for _ in columns)+' |']+
      ['| '+' | '.join(str(f(r)) for _,f in columns)+' |' for r in rows])

def main():
    rows=read_csv(ROOT/'results.csv');assert len(rows)==378
    data=load_data();Y=data['test']['Y'];n=len(Y);systems=data['systems']
    accuracy=read_csv(ROOT/'system_accuracy.csv')
    keys=sorted(set((r['method'],r['rho'],r['nominal_audit_fraction']) for r in rows))
    envelopes=[]
    for method,rho,b in keys:
        rr=[r for r in rows if (r['method'],r['rho'],r['nominal_audit_fraction'])==(method,rho,b)]
        u=min(rr,key=lambda r:r['utility']);h=max(rr,key=lambda r:r['harm'])
        env={'method':method,'rho':rho,'fraction':b,'cost_cap':u['total_cost_cap'],
          'utility':u['utility'],'utility_lower':min(r['utility_lower'] for r in rr),
          'utility_upper':min(r['utility_upper'] for r in rr),'harm':h['harm'],
          'harm_upper':max(r['harm_upper'] for r in rr),'harm_lower':max(r['harm_lower'] for r in rr),
          'expected_cost':max(r['expected_cost'] for r in rr),
          'mean_labels':max(r['mean_audit_labels'] for r in rr),'utility_scenario':u['scenario'],
          'harm_scenario':h['scenario']}
        envelopes.append(env)
    save_csv(ROOT/'risk_cost_envelopes.csv',envelopes)
    # These are measured configuration comparisons, not a completeness theorem.
    comparisons=[]
    for m in ['joint_proxy_shrinkage','exact_stratified']:
      for p in [r for r in envelopes if r['method']==m]:
        for c in [r for r in envelopes if r['method']!=m and r['rho']==p['rho']]:
          cheaper=p['expected_cost']<=c['expected_cost']+1e-8
          comparisons.append({'proposed':m,'rho':p['rho'],'proposed_fraction':p['fraction'],
             'comparator':c['method'],'comparator_fraction':c['fraction'],
             'utility_difference':p['utility']-c['utility'],'cost_difference':p['expected_cost']-c['expected_cost'],
             'both_harm_upper_below_0.01':p['harm_upper']<=.01 and c['harm_upper']<=.01,
             'confidence_separated_utility_at_no_higher_expected_cost':cheaper and p['utility_lower']>c['utility_upper'],
             'point_estimate_dominates':cheaper and p['harm']<=c['harm'] and p['utility']>=c['utility'] and
               (p['expected_cost']<c['expected_cost'] or p['utility']>c['utility'] or p['harm']<c['harm'])})
    save_csv(ROOT/'comparisons.csv',comparisons)
    # Resampling questions is distinct from resampling the private audit coins.
    rng=np.random.default_rng(202610196);indices=rng.integers(0,n,(10000,n))
    means=Y[indices].mean(axis=1);gaps=means-means[:,[0]]
    qs=[]
    for j,s in enumerate(systems):
        qs.append({'system':s,'accuracy':Y[:,j].mean(),'gain':Y[:,j].mean()-Y[:,0].mean(),
                   'question_bootstrap_accuracy_lower':np.quantile(means[:,j],.025),
                   'question_bootstrap_accuracy_upper':np.quantile(means[:,j],.975),
                   'question_bootstrap_gain_lower':np.quantile(gaps[:,j],.025),
                   'question_bootstrap_gain_upper':np.quantile(gaps[:,j],.975)})
    save_csv(ROOT/'question_uncertainty.csv',qs)
    jrows=[]
    for j,suffix in enumerate(data['suffixes']):
        scores=data['test']['cube'][j];pred=scores>=.5
        jrows.append({'suffix':suffix,'mean_score':scores.mean(),'binary_judge_accuracy':(pred==Y).mean(),
          'brier_score':((scores-Y)**2).mean(),
          'mean_score_on_incorrect':scores[Y==0].mean(),'mean_score_on_correct':scores[Y==1].mean(),
          'verdict_flip_rate_vs_clean':(pred!=(data['test']['cube'][0]>=.5)).mean()})
    save_csv(ROOT/'judge_diagnostics.csv',jrows)
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,
                         'figure.facecolor':'white','axes.titleweight':'bold'})
    selected=['trusted_uniform','trusted_disagreement','trusted_dev_challenger','ppi_uniform','robust_asi_l2',
              'joint_proxy_shrinkage','exact_stratified','pp_lucb_safe']
    colors=plt.get_cmap('tab10').colors
    fig,axes=plt.subplots(1,3,figsize=(15,5),sharey=True)
    for ax,rho in zip(axes,[5,20,50]):
      for j,m in enumerate(selected):
        rr=sorted([r for r in envelopes if r['method']==m and r['rho']==rho],key=lambda r:r['expected_cost'])
        xx=[r['expected_cost'] for r in rr];yy=[100*r['utility'] for r in rr]
        ax.plot(xx,yy,color=colors[j],alpha=.7,lw=1.5)
        for r in rr:
          ok=r['harm_upper']<=.01
          ax.errorbar(r['expected_cost'],100*r['utility'],
            yerr=[[100*(r['utility']-r['utility_lower'])],[100*(r['utility_upper']-r['utility'])]],
            fmt='o',ms=5,color=colors[j],mfc=colors[j] if ok else 'white',capsize=2,lw=.8)
      ax.axhline(0,color='#64748b',lw=.7)
      ax.axhline(100*(Y.mean(0).max()-Y[:,0].mean()),color='#64748b',ls=':',lw=.8)
      ax.set_title('Trusted label / judge cost = '+str(rho));ax.set_xlabel('Total evaluation cost (judge-call units)')
      ax.ticklabel_format(style='plain',axis='x');ax.grid(axis='y',alpha=.15)
    axes[0].set_ylabel('Worst observed improvement (percentage points)')
    handles=[plt.Line2D([0],[0],color=colors[j],marker='o',label=LABELS[m]) for j,m in enumerate(selected)]
    fig.legend(handles=handles,loc='lower center',ncol=4,fontsize=9,frameon=False)
    fig.suptitle('Frozen GSM8K systems: clean, utility attack and harm attack',fontsize=15,fontweight='bold')
    fig.text(.5,.14,'Filled points: conditional Monte Carlo harm upper bound ≤ 1%. Error bars concern audit randomness only.',ha='center',fontsize=9)
    fig.subplots_adjust(bottom=.25,top=.84,wspace=.15)
    fig.savefig(ROOT/'safety_utility_cost.png',dpi=180);fig.savefig(ROOT/'safety_utility_cost.svg');plt.close(fig)
    primary=[r for r in envelopes if r['rho']==20]
    columns=[('Method',lambda r:LABELS[r['method']]),('Budget fraction',lambda r:number(r['fraction'])),
      ('Expected cost',lambda r:number(r['expected_cost'])),('Worst improvement',lambda r:percent(r['utility'])),
      ('Worst harmful selection',lambda r:percent(r['harm'])),('Harm upper bound',lambda r:percent(r['harm_upper']))]
    detailed='# Frozen GSM8K decision experiment\n\n'
    detailed+='All cost settings and methods are retained. Improvement is an absolute difference in accuracy, reported as percentage points. The worst observation takes the minimum improvement or maximum harm across the clean, utility-targeted and harm-targeted conditions. It does not certify the worst possible text attack.\n\n'
    detailed+='## Frozen systems\n\n'+table([r for r in accuracy if r['split']=='test'],[
      ('System',lambda r:r['system']),('Accuracy',lambda r:percent(r['accuracy'])),
      ('Invalid final answer',lambda r:percent(r['parse_failure_rate'])),('Hit generation cap',lambda r:percent(r['token_cap_rate'])),
      ('Mean output tokens',lambda r:number(r['mean_tokens']))])+'\n\n'
    detailed+='## Primary cost ratio: 20\n\n'+table(primary,columns)+'\n\n'
    detailed+='## All cost ratios\n\nFor ratios 5 and 50 and all individual attacks, see `results.csv` and `risk_cost_envelopes.csv`. Each row uses 5,000 final audit replications. The simultaneous Monte Carlo intervals account for 504 final rows: 378 primary rows and 126 exploratory stress rows. These are repetitions of audit randomness over the same 300 questions, not 5,000 independent datasets.\n\n'
    stress=read_csv(ROOT/'stress_15_percent'/'results.csv');stress_env=[]
    for method,b in sorted(set((r['method'],r['nominal_audit_fraction']) for r in stress)):
        rr=[r for r in stress if r['method']==method and r['nominal_audit_fraction']==b]
        stress_env.append({'method':method,'rho':20,'fraction':b,'cost_cap':rr[0]['total_cost_cap'],
          'expected_cost':max(r['expected_cost'] for r in rr),'utility':min(r['utility'] for r in rr),
          'utility_lower':min(r['utility_lower'] for r in rr),'utility_upper':min(r['utility_upper'] for r in rr),
          'harm':max(r['harm'] for r in rr),'harm_upper':max(r['harm_upper'] for r in rr)})
    save_csv(ROOT/'stress_15_percent'/'risk_cost_envelopes.csv',stress_env)
    detailed+='## Exploratory 15% stress test\n\nThe exact ranking diagnostic found that 76 edits can block the useful update, while 113 are required to select the inferior system. The original cap of 90 therefore cannot exercise harmful judge-only deployment after answer-consistency projection. This follow-up raises the cap to 135, includes exact ranking attack witnesses, and uses fresh final audit seeds. It changes no defender or model output. It is exploratory evidence on the same questions.\n\n'
    detailed+='The table below shows every method at the middle budget. The full three-budget stress grid is in `stress_15_percent/results.csv`.\n\n'+table([r for r in stress_env if r['fraction']==.2],columns)+'\n\n'
    plot_methods=['development_only','judge_only','trusted_dev_challenger','trusted_disagreement',
                  'ppi_uniform','joint_proxy_shrinkage','exact_stratified','pp_lucb_safe']
    labels=['Development\nwinner','Judge\nonly','Trusted selected\nchallenger','Trusted all\ndisagreements',
            'PPI uniform\n(Wald)','Joint shrinkage\n(Wald)','Exact judge\nstrata','PP-LUCB\nsafe adapter']
    fig,ax=plt.subplots(figsize=(14,5.5));xx=np.arange(len(plot_methods))
    for z,b in enumerate([.1,.2,.4]):
        selected_rows=[next(r for r in stress_env if r['method']==m and r['fraction']==b) for m in plot_methods]
        yy=np.array([100*r['utility'] for r in selected_rows]);low=np.array([100*r['utility_lower'] for r in selected_rows]);up=np.array([100*r['utility_upper'] for r in selected_rows])
        ax.bar(xx+(z-1)*.25,yy,.23,color=['#234864','#087f8c','#e2a13d'][z],
               label='Budget '+number(selected_rows[0]['cost_cap']),yerr=np.array([yy-low,up-yy]),capsize=2,error_kw={'lw':.7})
    ax.axhline(0,color='#475569',lw=.8);ax.set_xticks(xx,labels,fontsize=9)
    ax.set_ylabel('Worst observed accuracy improvement (percentage points)')
    ax.set_title('15% response-edit stress test: trusted evidence preserves useful updates')
    ax.legend(loc='upper right',ncol=3,frameon=False,fontsize=9)
    ax.set_ylim(-21,32);ax.grid(axis='y',alpha=.15);ax.set_axisbelow(True)
    fig.text(.5,.02,'Development winner has no held-out certificate. Exact methods certify finite-pool risk; Wald results are empirical.',ha='center',fontsize=9)
    fig.tight_layout(rect=[0,.06,1,1]);fig.savefig(ROOT/'stress_comparison.png',dpi=180);fig.savefig(ROOT/'stress_comparison.svg');plt.close(fig)
    detailed+='## Judge diagnostics\n\nThese rows apply each suffix everywhere only to characterize its effect. The deployment attacks are separately capped at 90 of 900 responses.\n\n'+table(jrows,[
      ('Suffix',lambda r:r['suffix']),('Mean score',lambda r:number(r['mean_score'])),
      ('Judge accuracy',lambda r:percent(r['binary_judge_accuracy'])),('Brier error',lambda r:number(r['brier_score'])),
      ('Changed verdict',lambda r:percent(r['verdict_flip_rate_vs_clean']))])+'\n\n'
    detailed+='## Evidence boundaries\n\nThe exact trusted and stratified rules control inferior-system selection on this fixed pool through simultaneous finite-population intervals, assuming truthful audits and a text attack committed before private sampling. Their statistical guarantee does not require the tested attack search to be exhaustive. Residual-Wald methods have asymptotic intervals only; the Monte Carlo bounds provide empirical evidence for the frozen attacks, not a security certificate. PP-LUCB uses its published confidence-sequence construction with explicit task adapters.\n\n'
    detailed+='Question-bootstrap intervals in `question_uncertainty.csv` describe resampling these questions. They do not establish transfer to another dataset, model family, or adaptive attacker. Neither these intervals nor 5,000 audit repetitions turn one question pool into an independent confirmation study.\n'
    (ROOT/'RESULTS.md').write_text(detailed)
    print(json.dumps({'report_rows':len(rows),'envelopes':len(envelopes),'comparisons':len(comparisons),
                      'test_systems':qs},indent=2))

if __name__=='__main__':main()
