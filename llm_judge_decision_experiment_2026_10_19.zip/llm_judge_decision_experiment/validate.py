"""Validate provenance, immutable task answers, attack budgets and result arithmetic."""
import hashlib,json,math
from decimal import Decimal
from pathlib import Path
import numpy as np
from grade import parse
from evaluate import load_data,summary,run_method,apply_attack,METHODS

ROOT=Path(__file__).resolve().parent

def records(name):return list(map(json.loads,(ROOT/name).read_text().splitlines()))

def main():
    protocol=json.loads((ROOT/'protocol.json').read_text())
    for split,source in protocol['dataset_files'].items():
        assert hashlib.sha256((ROOT/'data'/f'{split}.jsonl').read_bytes()).hexdigest()==source['sha256']
    questions=records('questions.jsonl');assert len(questions)==len(set(q['question'] for q in questions))==400
    q={r['id']:r for r in questions}
    raw=records('generations.jsonl');graded=records('graded_generations.jsonl')
    assert len(raw)==len(graded)==1200
    assert len(set(r['id'] for r in raw))==1200
    g={r['id']:r for r in graded}
    for r in raw:
        z=g[r['id']];answer,_=parse(r['text'])
        assert z['parsed_answer']==(str(answer) if answer is not None else None)
        assert z['correct']==(answer is not None and answer==Decimal(q[r['question_id']]['gold'].replace(',','')))
        assert z['text']==r['text'] and r['split']==q[r['question_id']]['split']
    frozen=json.loads((ROOT/'frozen_attacks.json').read_text());suffixes=frozen['library']
    selected=['clean']+frozen['suffix_ids']
    main=records('judge_scores.jsonl');tune=records('attack_tuning_scores.jsonl')
    assert len(main)==1080*len(selected)==len(set(r['id'] for r in main))
    assert len(tune)==900==len(set(r['id'] for r in tune))
    for r in main+tune:
        assert r['suffix_tokens']<=128
        target=g[r['question_id']+':'+r['system']]
        text=target['text']+('\n\n'+suffixes[r['suffix']] if suffixes[r['suffix']] else '')
        assert parse(text)==parse(target['text'])
        score=1/(1+math.exp(-(r['logit_correct']-r['logit_incorrect'])))
        assert abs(r['score']-score)<1e-12
        assert 0<=r['label_mass']<=1.000001
    data=load_data();files=list((ROOT/'evaluation').glob('*.json'));assert len(files)==126
    stress_files=list((ROOT/'stress_15_percent'/'evaluation').glob('*.json'));assert len(stress_files)==42
    files+=stress_files
    for file in files:
        r=json.loads(file.read_text());saved=np.load(file.with_suffix('.npz'))
        assert len(r['rows'])==3
        for key in ['attack_mask','harm_attack_mask']:
            mask=np.array(r[key]);np.testing.assert_array_equal(mask,saved[key])
            cap=135 if file in stress_files else 90
            assert mask.shape==(300,3) and np.count_nonzero(mask)<=cap
            assert mask.min()>=0 and mask.max()<len(selected)
        for row in r['rows']:
            choice=saved[row['scenario']+'_choices'];assert len(choice)==5000
            values=summary(choice,data['test']['Y'])
            for key,value in values.items():assert abs(row[key]-value)<1e-12,(file,key)
            assert row['harm_lower']<=row['harm']<=row['harm_upper']
            assert row['utility_lower']<=row['utility']<=row['utility_upper']
            assert row['interval_family']==504
            assert row['expected_cost']<=row['total_cost_cap']+1e-6
            if row['method'] in ['trusted_uniform','trusted_disagreement','trusted_dev_challenger','exact_stratified','pp_lucb','pp_lucb_safe']:
                assert row['max_realized_cost']<=row['total_cost_cap']+1e-6
    # Re-run one genuine attack witness through two different selectors.
    for folder in [ROOT,ROOT/'stress_15_percent']:
      for method in ['joint_proxy_shrinkage','exact_stratified']:
        f=folder/'evaluation'/f'{method}_rho20_b0.2.json';r=json.loads(f.read_text())
        old=np.load(f.with_suffix('.npz'))
        row=next(x for x in r['rows'] if x['scenario']=='adaptive')
        score=apply_attack(data['test']['cube'],np.array(r['attack_mask']))
        choice,counts,_=run_method(method,score,data,row['total_cost_cap'],20,.2,5000,row['final_audit_seed'])
        np.testing.assert_array_equal(choice,old['adaptive_choices'])
        assert abs(counts['cost'].mean()-row['mean_cost'])<1e-8
    result={'status':'passed','generation_records':len(raw),'main_judge_records':len(main),
      'attack_tuning_records':len(tune),'configurations':len(files),'result_rows':3*len(files),
      'final_audit_replications_per_row':5000,'attack_witness_replays':4,
      'checks':['pinned dataset hashes','unique generation and score records','canonical reference grading',
        'all judged suffixes preserve the task answer','score reconstruction from raw logits',
        'all attack masks respect the response and token caps','saved decisions reproduce result arithmetic',
        'expected costs respect budgets; fixed-size methods respect hard budgets','four full witness replays']}
    (ROOT/'validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

if __name__=='__main__':main()
