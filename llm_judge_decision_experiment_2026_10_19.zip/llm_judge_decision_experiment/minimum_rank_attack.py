"""Post-hoc minimum-edit attack on the projected judge's three-way choice."""
import json
from pathlib import Path
import numpy as np
from scipy.optimize import milp,Bounds,LinearConstraint
from evaluate import load_data,apply_attack
from methods import project_scores
ROOT=Path(__file__).resolve().parent

def main():
    d=load_data();cube=d['test']['cube'];raw=cube[0];ans=d['test']['answers']
    n,k=raw.shape;means=project_scores(raw,ans).mean(0);out=[]
    for target in range(k):
        others=[j for j in range(k) if j!=target];coeff=np.zeros((k-1,n,k));modes=np.zeros((n,k),int)
        for i in range(n):
          for value in np.unique(ans[i]):
            group=ans[i]==value
            if value=='None':continue
            for a,other in enumerate(others):coeff[a,i,group]=(int(group[target])-int(group[other]))/(group.sum()*n)
            choices=cube[:,i,:].argmax(axis=0) if group[target] else cube[:,i,:].argmin(axis=0)
            modes[i,group]=choices[group]
        extreme=apply_attack(cube,modes)
        gain=(coeff*(extreme-raw)[None,:,:]).reshape(k-1,-1)
        assert gain.min()>-1e-12
        active=np.flatnonzero(gain.max(0)>1e-12)
        rhs=means[others]-means[target]+0.00001
        fit=milp(np.ones(len(active)),integrality=np.ones(len(active)),bounds=Bounds(0,1),
                 constraints=LinearConstraint(gain[:,active],rhs,np.inf),options={'time_limit':30})
        result={'target':d['systems'][target],'status':int(fit.status),'message':fit.message,
                'scope':'frozen text library; unchanged numerical answers; strict winning margin 0.00001'}
        if fit.x is not None:
            mask=np.zeros_like(modes);take=active[fit.x>.5];mask.ravel()[take]=modes.ravel()[take]
            attacked=project_scores(apply_attack(cube,mask),ans);selected=int(attacked.mean(0).argmax())
            assert selected==target,(result,attacked.mean(0))
            result.update(edited_responses=int(np.count_nonzero(mask)),fraction=float(np.count_nonzero(mask)/raw.size),
                          selected_system=d['systems'][selected],score_means=attacked.mean(0).tolist(),
                          solver_gap=float(fit.mip_gap),mask=mask.tolist())
        out.append(result)
    (ROOT/'minimum_rank_attacks.json').write_text(json.dumps(out,indent=2)+'\n')
    for r in out:print(json.dumps({key:value for key,value in r.items() if key!='mask'}))

if __name__=='__main__':main()
