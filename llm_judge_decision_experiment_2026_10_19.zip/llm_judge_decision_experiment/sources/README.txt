PRIMARY SOURCES AND IMPLEMENTATION BOUNDARIES

GSM8K: https://github.com/openai/grade-school-math
Pinned dataset commit and file hashes are in protocol.json. Question-level splits
were fixed before generation. Fresh means held out from this experiment; we have
not established absence from model pretraining.

Shi et al., Optimization-based Prompt Injection Attack to LLM-as-a-Judge (CCS 2024)
https://arxiv.org/abs/2403.17710
Prior local upstream commit: 7cfc96af0272befd83220b1d7d3b0699d072ecbf.
Two released suffixes are transfer controls. This pilot adds a bounded black-box
suffix/composition search, not a gradient reproduction of JudgeDeceiver.

Zrnic and Candes, Active Statistical Inference (ICML 2024)
https://proceedings.mlr.press/v235/zrnic24a.html
Prediction plus inverse-probability residual correction; uncertainty-based audits.

Li, Zrnic and Candes, Robust Sampling for Active Statistical Inference (NeurIPS 2025)
https://arxiv.org/abs/2511.08991
Source pinned in robust_sampling_upstream.json. The l2 minimax objective was
checked against the isolated upstream class. Feature regression and shared
contrast auditing are documented task adapters in baseline_fidelity.json.

Ao et al., Best Arm Identification with LLM Judges and Limited Human Audits (2026)
https://arxiv.org/html/2601.21471v1
Reimplemented estimator, confidence widths, best/challenger pulls, and Neyman
updates. Budget fallback and an incumbent-relative stopping rule are adapters.
No claim that a finite-pool pilot reproduces all paper experiments.

Angelopoulos, Duchi and Zrnic, PPI++: Efficient Prediction-Powered Inference
https://arxiv.org/abs/2311.01453
Proxy coefficient selection is established prior work. Our joint shrinkage/audit
rule is an experimental combination, not an established novel method.
