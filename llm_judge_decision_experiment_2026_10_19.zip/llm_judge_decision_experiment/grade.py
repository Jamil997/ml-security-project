"""Canonical numeric grading, separately versioned from raw generation records.

Development inspection exposed two issues in the initial strict parser: prose
before a final number was rejected; the hour prefix of a clock time was accepted.
This parser is frozen before test generation and never consults gold to parse.
"""
import json
import re
from decimal import Decimal
from pathlib import Path
import hashlib
import argparse

ROOT = Path(__file__).resolve().parent
VERSION = "numeric-final-line-v2"


def parse(text):
    lines = re.findall(r"(?im)^\s*(?:\*\*)?Final answer\s*:\s*(.*)$", text)
    if len(lines) != 1:
        return None, "missing_or_multiple_final_lines"
    line = lines[0].replace("**", "").strip()
    if re.search(r"\d\s*:\s*\d", line):
        return None, "clock_time_or_ratio"
    if re.search(r"\d\s*/\s*\d", line):
        return None, "fraction_requires_review"
    nums = re.findall(r"(?<![\w.])-?\d[\d,]*(?:\.\d+)?", line)
    if len(nums) != 1:
        return None, "ambiguous_numeric_line"
    value = Decimal(nums[0].replace(",", ""))
    return value, "parsed"


def graded():
    qs = {q["id"]: q for q in map(json.loads, (ROOT / "questions.jsonl").read_text().splitlines())}
    out = []
    for r in map(json.loads, (ROOT / "generations.jsonl").read_text().splitlines()):
        val, status = parse(r["text"])
        gold = Decimal(qs[r["question_id"]]["gold"].replace(",", ""))
        out.append({**r, "grading_version": VERSION, "parsed_answer": str(val) if val is not None else None,
                    "grading_status": status, "correct": val is not None and val == gold})
    return out


def main():
    ap = argparse.ArgumentParser();ap.add_argument("--freeze",action="store_true");args=ap.parse_args()
    rows = graded()
    (ROOT / "graded_generations.jsonl").write_text("".join(json.dumps(r)+"\n" for r in rows))
    if args.freeze:
        p=ROOT / "frozen_systems.json"
        assert not p.exists()
        dev = [r for r in rows if r["split"] == "development"]
        assert len(dev)==120 and not any(r["split"]=='test' for r in rows)
        systems = sorted(set(r["system"] for r in dev))
        acc = {a:sum(r["correct"] for r in dev if r["system"]==a)/40 for a in systems}
        ranking=sorted(systems,key=lambda a:(acc[a],a))
        frozen={"development_accuracy":acc,"incumbent":ranking[1],"development_ranking":ranking,
                "grading_version":VERSION,"grading_code_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                "test_generations_seen":0,"selection_rule":"median development accuracy, stable id tie-break"}
        p.write_text(json.dumps(frozen,indent=2)+"\n")
        print(json.dumps(frozen),flush=True)


if __name__ == "__main__": main()
