"""Reproduce in a NEW directory, preserving the original study and outputs."""
import argparse,json,shutil,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--output',type=Path,required=True)
    ap.add_argument('--full-inference',action='store_true')
    ap.add_argument('--model-dir',type=Path)
    args=ap.parse_args();dest=args.output.resolve()
    if dest.exists():raise SystemExit('Output must be a new directory; existing results will not be overwritten.')
    if args.full_inference and not args.model_dir:
        raise SystemExit('--full-inference requires --model-dir pointing to the pinned MLX model.')
    dest.mkdir(parents=True)
    names=['protocol.json','questions.jsonl','analysis_protocol.json','implementation_amendments.json',
      'attack_library.json','generate.py','grade.py','judge.py','methods.py','pp_lucb.py',
      'evaluate.py','report.py','validate.py','test_methods.py','rank_diagnostic.py',
      'minimum_rank_attack.py','refresh_intervals.py']
    if not args.full_inference:
        names+=['generations.jsonl','graded_generations.jsonl','frozen_systems.json',
                'frozen_attacks.json','attack_tuning_scores.jsonl','judge_scores.jsonl']
    for name in names:shutil.copy2(ROOT/name,dest/name)
    shutil.copytree(ROOT/'data',dest/'data')
    commands=[]
    if args.full_inference:
        model=str(args.model_dir.resolve())
        commands=[['generate.py','--split','development','--model-dir',model],['grade.py','--freeze'],
          ['generate.py','--split','calibration','--model-dir',model],
          ['generate.py','--split','test','--model-dir',model],['grade.py'],
          ['judge.py','--stage','tune','--model-dir',model],['judge.py','--stage','evaluate','--model-dir',model]]
    commands+=[['-m','unittest','test_methods','-v'],['evaluate.py'],['rank_diagnostic.py'],
      ['minimum_rank_attack.py'],['evaluate.py','--primary-only','--attack-fraction','.15',
      '--output-dir','stress_15_percent','--audit-seed','202610199'],
      ['refresh_intervals.py'],['report.py'],['validate.py']]
    for command in commands:
        print('Running:',*command,flush=True)
        subprocess.run([sys.executable]+command,cwd=dest,check=True)
    print('Reproduction saved to',dest)

if __name__=='__main__':main()
