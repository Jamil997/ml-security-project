# Frozen GSM8K decision experiment

All cost settings and methods are retained. Improvement is an absolute difference in accuracy, reported as percentage points. The worst observation takes the minimum improvement or maximum harm across the clean, utility-targeted and harm-targeted conditions. It does not certify the worst possible text attack.

## Frozen systems

| System | Accuracy | Invalid final answer | Hit generation cap | Mean output tokens |
| --- | --- | --- | --- | --- |
| concise | 18.667% | 47% | 13.667% | 100.43 |
| direct | 3% | 44.333% | 71.667% | 40.9 |
| reasoned | 42.667% | 21.333% | 5.667% | 188.69 |

## Primary cost ratio: 20

| Method | Budget fraction | Expected cost | Worst improvement | Worst harmful selection | Harm upper bound |
| --- | --- | --- | --- | --- | --- |
| ASI uncertainty (Wald) | 0.1 | 6480 | 1.085% | 0% | 0.212% |
| ASI uncertainty (Wald) | 0.2 | 8280 | 6.432% | 0% | 0.212% |
| ASI uncertainty (Wald) | 0.4 | 11880 | 18.758% | 0% | 0.212% |
| Development winner, no new audit | 0.1 | 0 | 24% | 0% | 0.212% |
| Development winner, no new audit | 0.2 | 0 | 24% | 0% | 0.212% |
| Development winner, no new audit | 0.4 | 0 | 24% | 0% | 0.212% |
| Exact judge strata | 0.1 | 6480 | 5.429% | 0% | 0.212% |
| Exact judge strata | 0.2 | 8280 | 19.661% | 0% | 0.212% |
| Exact judge strata | 0.4 | 11880 | 24% | 0% | 0.212% |
| Joint shrinkage (Wald) | 0.1 | 6480 | 8.17% | 0% | 0.212% |
| Joint shrinkage (Wald) | 0.2 | 8280 | 20.875% | 0% | 0.212% |
| Joint shrinkage (Wald) | 0.4 | 11880 | 24% | 0% | 0.212% |
| Judge only | 0.1 | 900 | 0% | 0% | 0.212% |
| Judge only | 0.2 | 900 | 0% | 0% | 0.212% |
| Judge only | 0.4 | 900 | 0% | 0% | 0.212% |
| Power-tuned uniform (Wald) | 0.1 | 6480 | 8.453% | 0% | 0.212% |
| Power-tuned uniform (Wald) | 0.2 | 8280 | 18.235% | 0% | 0.212% |
| Power-tuned uniform (Wald) | 0.4 | 11880 | 24% | 0% | 0.212% |
| PP-LUCB adapter | 0.1 | 6466.953 | 0% | 0% | 0.212% |
| PP-LUCB adapter | 0.2 | 8268.259 | 0% | 0% | 0.212% |
| PP-LUCB adapter | 0.4 | 11869.316 | 0% | 0% | 0.212% |
| PP-LUCB safe-update adapter | 0.1 | 6466.953 | 0% | 0% | 0.212% |
| PP-LUCB safe-update adapter | 0.2 | 8268.259 | 0% | 0% | 0.212% |
| PP-LUCB safe-update adapter | 0.4 | 11869.316 | 0% | 0% | 0.212% |
| PPI uniform (Wald) | 0.1 | 6480 | 16.685% | 0% | 0.212% |
| PPI uniform (Wald) | 0.2 | 8280 | 21.706% | 0% | 0.212% |
| PPI uniform (Wald) | 0.4 | 11880 | 24% | 0% | 0.212% |
| Retain incumbent | 0.1 | 0 | 0% | 0% | 0.212% |
| Retain incumbent | 0.2 | 0 | 0% | 0% | 0.212% |
| Retain incumbent | 0.4 | 0 | 0% | 0% | 0.212% |
| Robust ASI adapter (Wald) | 0.1 | 6480 | 4.445% | 0% | 0.212% |
| Robust ASI adapter (Wald) | 0.2 | 8280 | 10.949% | 0% | 0.212% |
| Robust ASI adapter (Wald) | 0.4 | 11880 | 22.368% | 0% | 0.212% |
| Trusted development challenger | 0.1 | 6480 | 24% | 0% | 0.212% |
| Trusted development challenger | 0.2 | 8280 | 24% | 0% | 0.212% |
| Trusted development challenger | 0.4 | 8520 | 24% | 0% | 0.212% |
| Trusted disagreement | 0.1 | 6480 | 23.976% | 0% | 0.212% |
| Trusted disagreement | 0.2 | 8280 | 24% | 0% | 0.212% |
| Trusted disagreement | 0.4 | 11880 | 24% | 0% | 0.212% |
| Trusted uniform | 0.1 | 6480 | 23.904% | 0% | 0.212% |
| Trusted uniform | 0.2 | 8280 | 24% | 0% | 0.212% |
| Trusted uniform | 0.4 | 11880 | 24% | 0% | 0.212% |

## All cost ratios

For ratios 5 and 50 and all individual attacks, see `results.csv` and `risk_cost_envelopes.csv`. Each row uses 5,000 final audit replications. The simultaneous Monte Carlo intervals account for 504 final rows: 378 primary rows and 126 exploratory stress rows. These are repetitions of audit randomness over the same 300 questions, not 5,000 independent datasets.

## Exploratory 15% stress test

The exact ranking diagnostic found that 76 edits can block the useful update, while 113 are required to select the inferior system. The original cap of 90 therefore cannot exercise harmful judge-only deployment after answer-consistency projection. This follow-up raises the cap to 135, includes exact ranking attack witnesses, and uses fresh final audit seeds. It changes no defender or model output. It is exploratory evidence on the same questions.

The table below shows every method at the middle budget. The full three-budget stress grid is in `stress_15_percent/results.csv`.

| Method | Budget fraction | Expected cost | Worst improvement | Worst harmful selection | Harm upper bound |
| --- | --- | --- | --- | --- | --- |
| ASI uncertainty (Wald) | 0.2 | 8280 | 0.874% | 0% | 0.212% |
| Development winner, no new audit | 0.2 | 0 | 24% | 0% | 0.212% |
| Exact judge strata | 0.2 | 8280 | 16.445% | 0% | 0.212% |
| Joint shrinkage (Wald) | 0.2 | 8280 | 19.037% | 0% | 0.212% |
| Judge only | 0.2 | 900 | -15.667% | 100% | 100% |
| Power-tuned uniform (Wald) | 0.2 | 8280 | 15.96% | 0% | 0.212% |
| PP-LUCB adapter | 0.2 | 8268.394 | 0% | 0% | 0.212% |
| PP-LUCB safe-update adapter | 0.2 | 8268.394 | 0% | 0% | 0.212% |
| PPI uniform (Wald) | 0.2 | 8280 | 20.318% | 0% | 0.212% |
| Retain incumbent | 0.2 | 0 | 0% | 0% | 0.212% |
| Robust ASI adapter (Wald) | 0.2 | 8280 | 8.966% | 0% | 0.212% |
| Trusted development challenger | 0.2 | 8280 | 24% | 0% | 0.212% |
| Trusted disagreement | 0.2 | 8280 | 24% | 0% | 0.212% |
| Trusted uniform | 0.2 | 8280 | 24% | 0% | 0.212% |

## Judge diagnostics

These rows apply each suffix everywhere only to characterize its effect. The deployment attacks are separately capped at 90 of 900 responses.

| Suffix | Mean score | Judge accuracy | Brier error | Changed verdict |
| --- | --- | --- | --- | --- |
| clean | 0.797 | 40.222% | 0.59 | 0% |
| up_combined | 0.999 | 21.556% | 0.784 | 20.222% |
| up_verdict | 0.986 | 22.889% | 0.77 | 18.889% |
| down_verdict | 0 | 78.556% | 0.214 | 79.667% |
| down_authority | 0 | 78.556% | 0.214 | 79.667% |
| published_q1 | 0.831 | 37.889% | 0.62 | 5.889% |

## Evidence boundaries

The exact trusted and stratified rules control inferior-system selection on this fixed pool through simultaneous finite-population intervals, assuming truthful audits and a text attack committed before private sampling. Their statistical guarantee does not require the tested attack search to be exhaustive. Residual-Wald methods have asymptotic intervals only; the Monte Carlo bounds provide empirical evidence for the frozen attacks, not a security certificate. PP-LUCB uses its published confidence-sequence construction with explicit task adapters.

Question-bootstrap intervals in `question_uncertainty.csv` describe resampling these questions. They do not establish transfer to another dataset, model family, or adaptive attacker. Neither these intervals nor 5,000 audit repetitions turn one question pool into an independent confirmation study.
