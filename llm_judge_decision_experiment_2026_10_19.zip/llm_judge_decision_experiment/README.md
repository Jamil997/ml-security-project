# Trusted audits for system selection under attacked LLM judgments

An attacker can change an evaluator's verdict without changing the answer being evaluated. The practical question is whether a limited budget of trustworthy checks can still support a useful deployment decision—and whether a language-model judge helps enough to justify its evaluation cost.

This experiment is the LLM-judge continuation of the OptDigits/E9 research direction. It retains the same incumbent-relative decision target, while replacing direct edits to numerical feedback with text attacks scored by an actual language model. The controlled setting makes answer correctness verifiable and allows us to separate changes in judge feedback from changes in the underlying system's quality.

The completed numerical findings are reported in [RESULTS.md](RESULTS.md), with every configuration retained in [results.csv](results.csv). [METHODS.md](METHODS.md) introduces the notation, connects the estimators to prior work, and explains the assumptions behind each confidence statement.

## Findings

The incumbent answered 18.667% of the held-out questions correctly, compared with 42.667% for the stronger configuration and 3% for the weaker one. The available useful update therefore gains 24 percentage points; choosing the weaker configuration loses 15.667 points.

Text attacks changed the deployment decision without changing these answers. An exact ranking calculation, checked by replaying the resulting text choices, found that **76 edited responses suffice to block the useful update, while 113 suffice to select the inferior system**. Matching lower bounds show that fewer edits cannot achieve these respective ranking changes after the declared answer-consistency projection. Thus the original 90-response cap tests denial of improvement but cannot make this projected judge select the bad system. Reporting zero harmful deployment at that cap as evidence that an audit defense succeeded would be misleading.

We therefore added an explicitly exploratory stress test allowing 135 edits, or 15% of the responses. It uses the same frozen outputs and scores, stronger ranking-attack witnesses, and independent final audit seeds. At the middle evaluation budget, with a trusted label costing 20 judge-query units, the worst observed results across clean and attacked conditions were:

| Selection rule | Additional expected evaluation cost | Improvement in accuracy, percentage points | Harmful deployment |
| --- | ---: | ---: | ---: |
| Development winner, without further verification | 0 | 24 | 0% |
| Judge with answer-consistency checks | 900 | -15.667 | 100% |
| Trusted verification of the development-selected challenger | 8280 | 24 | 0% |
| Uniform prediction-powered correction | 8280 | 20.318 | 0% |
| Proposed joint shrinkage and allocation | 8280 | 19.037 | 0% |
| Exact judge-stratified gate | 8280 | 16.445 | 0% |

Costs are simulated evaluation units, not cash expenditures. Development data and response generation are common prior costs. The development-only rule has no held-out safety certificate. The exact trusted and stratified gates have a finite-pool design guarantee; the normal-interval methods have empirical evidence here. A reported 0% means no harmful selections in the 5,000 final audit replications for each condition. Its simultaneous Monte Carlo upper bound is 0.212%, conditional on this question pool and the searched attacks.

![Exploratory stress comparison](stress_comparison.png)

The experiment demonstrates a useful role for trustworthy verification when judge feedback is attacked. It also exposes the current method's economic weakness. At the middle budget, the joint rule pays for 60 calibration questions and can afford only 60 test-question audits on average. The trusted challenger control uses the existing development ranking and can verify 207 test questions. The joint rule does not recover enough precision to compensate for its calibration and evaluation overhead.

There is a narrower positive ablation: joint shrinkage and allocation gains 19.037 points under the stress attack, compared with 15.960 for calibrated coefficient tuning with uniform audits at the same cost. This supports the combined design within that calibrated comparison, although coefficient selection and allocation both change, so their individual contributions are not isolated. However, ordinary uniform prediction-powered correction reaches 20.318 points and trusted-only verification reaches 24. The proposed combinations tie or lose to the trusted challenger at every matched setting in this study. They do not establish an improved Pareto frontier.

The development-only control reveals a second limitation: the best development configuration remains best on this test pool. This makes the benchmark useful for studying certification and attacks on evaluation, but too easy for demonstrating that a new selector improves the actual deployment choice beyond the available development evidence.

## Research consequence

The next method should decide whether the judge is worth purchasing at all. It should be able to choose trusted-only verification, uniform residual correction, or active auditing after a small, explicitly charged pilot. The comparison must count the cost of learning that choice. Choosing a zero proxy coefficient after paying for a full judge pass and calibration does not recover the economical trusted-only option.

A useful theoretical target is a finite-sample comparison with the cheaper of trusted-only and proxy-assisted certification, plus an explicit cost for identifying the appropriate strategy, while controlling harmful deployment under committed adversarial feedback. Existing residual correction, coefficient tuning, and robust sampling are the starting points for this analysis; combining their names is insufficient as a novelty claim.

For independent confirmation, freeze closer competing systems and multiple task populations using development data only. Keep the development-only rule, trusted selected-challenger rule, uniform correction, and published auditing adapters as comparators. Select the attack budgets from declared decision-margin tests, and evaluate on new questions before tuning the method further. The present 24-point quality gap and high final-answer formatting failure rates make broader claims about model selection premature. A paper would need reliable improvement in certification cost against these strong controls, a defensible finite-sample result, and confirmation beyond this one model and dataset.

## Experimental design

We generated responses to 400 GSM8K questions using three frozen prompting configurations of the same quantized Mistral-7B-Instruct model. Forty development questions determined the incumbent and the text-attack library; 60 independent calibration questions were available to methods that paid for them; 300 questions formed the held-out evaluation pool. The incumbent was fixed before any test response was generated. These are questions held out from this experiment, not questions known to be absent from model pretraining.

The configurations request a direct answer, concise calculations, or longer step-by-step reasoning. They use different fixed output limits. Thus the comparison concerns complete prompting configurations, including their ability to produce the required final-answer format. It is not a comparison of independently trained models or a measure of proof quality. A correct final numerical answer receives one and an incorrect or invalid final answer receives zero.

We evaluate 14 selection rules at three total budgets and three assumed ratios between trusted-label and judge-query cost. Every rule can retain the incumbent. The primary outcomes are improvement in actual answer accuracy, the probability of selecting a worse system, and total evaluation cost. Calibration is charged. Trusted-only methods can buy additional labels with the money other methods spend on judge calls and calibration. Oracle labels come from benchmark references; their prices are simulated, and no human annotation expenses were incurred.

The strongest practical trusted-only control preselects its challenger from the frozen development ranking and verifies only that system against the incumbent. It pays for two labels per audit, does not consult test truth when choosing its challenger, and can use answer agreement to avoid unnecessary purchases.

Two attack objectives are tested separately: suppress useful improvement and induce harmful deployment. The attacker can append up to 128 tokens to at most 90 of the 900 test responses while preserving their parsed answers. It knows the selector and can use reference labels to search for strong placements. It has query access to the judge but no gradient access. It cannot change trusted labels, calibration data, or the defender's future private audit draws. Each attack search uses 128 audit replications, followed by 5,000 independent replications for evaluation.

This yields 378 reported rows: 14 rules, three budgets, three cost ratios, and three conditions (clean, utility attack, harm attack). These repetitions quantify audit randomness on one fixed question pool. They are not independent benchmark replications.

The exploratory 15% stress test adds 126 rows at cost ratio 20. Final Monte Carlo intervals account jointly for all 504 rows. `stress_protocol.json` records why this extension was introduced. The original weaker attack pass is preserved in `phase1/`; final results use projection-aware attacks and fresh audit seeds. The nonlinear selectors are still attacked heuristically, whereas the ranking diagnostic has an exact combinatorial calculation.

## What comes from earlier work

| Work | Role in this experiment | Implementation boundary |
| --- | --- | --- |
| [Shi et al., JudgeDeceiver](https://arxiv.org/abs/2403.17710) | Text attacks on judge feedback; two released suffixes are transfer controls. | Bounded black-box library search; no reproduction of their gradient optimization. |
| [Zrnic and Candès, Active Statistical Inference](https://proceedings.mlr.press/v235/zrnic24a.html) | Prediction plus inverse-probability residual correction. | Paired system differences and shared audit bundles. |
| [Angelopoulos et al., PPI++](https://arxiv.org/abs/2311.01453) | Tuning the contribution of an imperfect predictor. | A finite coefficient grid with a paired, finite-pool variance objective. |
| [Li et al., Robust Sampling](https://arxiv.org/abs/2511.08991) | Robust interpolation between active and uniform audit allocation. | Released L2 objective verified; binned residual models and shared contrasts are adaptations. |
| [Ao et al., Best Arm Identification with LLM Judges and Limited Human Audits](https://arxiv.org/html/2601.21471v1) | Sequential residual estimation and confidence-based selection. | Published construction with documented finite-budget and finite-pool adapters. |

Our experimental combinations are joint proxy shrinkage with robust allocation, and an exact judge-stratified decision gate. Neither coefficient tuning nor stratified confidence intervals is itself new. The proposed empirical contribution is to connect actual text manipulation, adaptive attacks on the complete selector, and the price of trustworthy evidence in one reproducible decision experiment. A new paper contribution would require a stronger result than showing that established auditing ideas can be implemented together.

## How to read the evidence

For the exact finite-pool rules, uniform private sampling within committed groups provides a risk guarantee even when the grouping is misleading. An attack can nevertheless make the method inefficient. For residual-based normal intervals, small-sample validity is not guaranteed; their observed failure rates must not be presented as universal robustness. The PP-LUCB adapter has a different sequential sampling and cost convention, detailed in METHODS.md.

The confidence bounds accompanying the result table account for all planned comparisons but remain conditional on the fixed pool and searched attacks. A heuristic attack that fails to find harm is not a security certificate. Likewise, a point estimate on the measured safety–utility–cost frontier is not a proof of Pareto optimality over all procedures or environments. A useful next claim would be a supported improvement in efficiency at a fixed harm ceiling against strong, cost-matched alternatives.

## Reproduce the decision experiment

The cached responses and real judge scores are sufficient to reproduce the statistical comparison on a CPU. The following command creates a new output directory and leaves the original evidence intact:

```bash
python -m pip install -r requirements.txt
python reproduce.py --output ../gsm8k-decision-reproduction
```

To regenerate model outputs as well, use an Apple Silicon environment with the packages in `requirements-inference.txt` and the pinned model revision recorded in `protocol.json`:

```bash
python reproduce.py --output ../gsm8k-full-reproduction \
  --full-inference --model-dir /absolute/path/to/the/pinned/model
```

The full procedure regenerates development responses, freezes the incumbent, generates calibration and test responses, selects attacks on development data, scores all conditions, runs the decision comparison, and validates the outputs. Model weights are excluded from the archive. Inference may differ across software or hardware versions; the recorded environment, model hashes, and raw outputs make that distinction inspectable.

## Files and provenance

- `protocol.json`, `analysis_protocol.json`, and `implementation_amendments.json`: original choices and transparent corrections, including their timing.
- `generations.jsonl`: original model outputs. Its original grading fields are superseded by the separately versioned canonical grading.
- `graded_generations.jsonl`: the frozen numerical-answer grading used in all results.
- `attack_tuning_scores.jsonl`, `frozen_attacks.json`, and `judge_scores.jsonl`: development search and real-model scores with raw logits.
- `evaluation/`: attack witnesses, selected systems for every audit replication, and per-configuration results.
- `risk_cost_envelopes.csv`, `comparisons.csv`, and `question_uncertainty.csv`: comparison summaries and separate question-resampling uncertainty.
- `test_methods.py` and `validation.json`: statistical unit checks and validation of the completed run.
- `environment.json`, `model_manifest.json`, and `sources/`: dependencies and source provenance.
- `rank_margin_diagnostic.csv`, `minimum_rank_attacks.json`, and their scripts: exact ranking thresholds and replayable text-attack witnesses.
- `stress_15_percent/`: the full exploratory higher-corruption comparison.

GSM8K is redistributed under its included MIT license. The attacks were tested locally on controlled mathematical examples; no third-party service was targeted. The existing OptDigits/E9 artifacts are separate and unchanged.
