"""Attack the final deployment decision at matched total expected cost.

All attack searches use independent audit seeds from final evaluation. Exact
finite-pool guarantees, Wald approximations and PP-LUCB are reported separately.
Attack search is a feasible lower bound on damage, never an exhaustive claim.
"""
import argparse
import csv
import hashlib
import json
import time
from pathlib import Path
import numpy as np
from scipy.stats import beta as beta_dist
from methods import (make_plan,normal_decisions,exact_decisions,summary,
                     differences,hypergeom_bounds,project_scores,answer_key,trusted_challenger)
from pp_lucb import run as pp_run

ROOT=Path(__file__).resolve().parent
METHODS=['retain','development_only','judge_only','trusted_uniform','trusted_disagreement','trusted_dev_challenger','ppi_uniform','power_tuned_uniform',
         'asi_uncertainty','robust_asi_l2','joint_proxy_shrinkage','exact_stratified','pp_lucb','pp_lucb_safe']
CALIBRATED={'power_tuned_uniform','robust_asi_l2','joint_proxy_shrinkage','pp_lucb','pp_lucb_safe'}
EXACT={'trusted_uniform','trusted_disagreement','exact_stratified'}
_ATTACK_POOL={}


def load_data():
    frozen=json.loads((ROOT/'frozen_systems.json').read_text())
    systems=[frozen['incumbent']]+[a for a in ['direct','concise','reasoned'] if a!=frozen['incumbent']]
    questions=list(map(json.loads,(ROOT/'questions.jsonl').read_text().splitlines()))
    gen={r['id']:r for r in map(json.loads,(ROOT/'graded_generations.jsonl').read_text().splitlines())}
    records=list(map(json.loads,(ROOT/'judge_scores.jsonl').read_text().splitlines()))
    scores={r['id']:r for r in records};assert len(scores)==len(records)
    attack=json.loads((ROOT/'frozen_attacks.json').read_text())
    suffixes=['clean']+attack['suffix_ids'];output={}
    for split in ['calibration','test']:
        ids=[q['id'] for q in questions if q['split']==split]
        Y=np.array([[float(gen[q+':'+a]['correct']) for a in systems] for q in ids])
        answers=np.array([[answer_key(gen[q+':'+a]['parsed_answer']) for a in systems] for q in ids])
        cube=np.array([[[scores[q+':'+a+':'+s]['score'] for a in systems] for q in ids] for s in suffixes])
        output[split]={'ids':ids,'Y':Y,'answers':answers,'cube':cube}
    output['systems']=systems;output['suffixes']=suffixes
    output['development_challenger']=systems.index(frozen['development_ranking'][-1])
    output['metadata']={'generations':len(gen),'judge_scores':len(scores),'model_queries':len(scores)+len((ROOT/'attack_tuning_scores.jsonl').read_text().splitlines())}
    return output


def apply_attack(cube,mask):
    n,k=mask.shape
    return cube[mask,np.arange(n)[:,None],np.arange(k)[None,:]]


def run_method(name,S,data,cost_cap,rho,budget,seeds,seed,params_only=False):
    Y=data['test']['Y'];answers=data['test']['answers'];n,k=Y.shape
    individual_scores=np.where(answers=='None',0.0,S)
    S=project_scores(S,answers)
    calS=project_scores(data['calibration']['cube'][0],data['calibration']['answers']);calY=data['calibration']['Y']
    cal_cost=(calS.size+rho*calY.size) if name in CALIBRATED else 0
    judge_cost=n*k if name not in {'retain','trusted_uniform','trusted_disagreement'} else 0
    if name=='retain':return np.zeros(seeds,int),{'cost':np.zeros(seeds),'audit_labels':np.zeros(seeds),'judge_queries':np.zeros(seeds)},{}
    if name=='development_only':
        return np.full(seeds,data['development_challenger'],int),\
          {'cost':np.zeros(seeds),'audit_labels':np.zeros(seeds),'judge_queries':np.zeros(seeds)},\
          {'boundary':'no held-out safety certificate; deploy the development winner without further evidence'}
    if name=='judge_only':
        choice=np.full(seeds,int(S.mean(axis=0).argmax()))
        return choice,{'cost':np.full(seeds,judge_cost),'audit_labels':np.zeros(seeds),'judge_queries':np.full(seeds,judge_cost)},{}
    if name=='trusted_dev_challenger':
        keys=np.random.default_rng(seed).random((seeds,n))
        choice,count,_=trusted_challenger(Y,answers,int(cost_cap/(2*rho)),keys,data['development_challenger'])
        return choice,{'cost':2*rho*count,'audit_labels':2*count,'judge_queries':np.zeros(seeds)},\
          {'boundary':'exact paired finite-pool interval; one development-selected challenger',
           'challenger':data['development_challenger'],'test_audit_cap':int(cost_cap/(2*rho))}
    if name.startswith('pp_lucb'):
        # A sequential single-arm query cannot average other arms' unpurchased
        # scores. Missing-answer zeros remain free; all calibration was paid.
        choices,counts=pp_run(individual_scores,Y,calS,calY,cost_cap,rho,budget,seeds,seed,safe_update=name.endswith('safe'))
        return choices,counts,{'boundary':'published confidence sequence; finite-pool iid sampling with replacement'}
    remain=max(0,cost_cap-cal_cost-judge_cost)
    audits=min(n,remain/(k*rho));frac=audits/n
    if audits<=0:return np.zeros(seeds,int),{'cost':np.zeros(seeds),'audit_labels':np.zeros(seeds),'judge_queries':np.zeros(seeds)},{'unaffordable':True}
    rng=np.random.default_rng(seed);keys=rng.random((seeds,n))
    if name in EXACT:
        choice,count,_=exact_decisions(S,Y,answers,int(audits),keys,name)
        meta={'boundary':'exact finite-pool hypergeometric, simultaneous across contrasts/strata','test_audit_cap':int(audits)}
    else:
        p,coef,meta=make_plan(name,S,frac,calS,calY)
        choice,count,_=normal_decisions(S,Y,p,coef,keys)
        meta={**meta,'boundary':'asymptotic paired residual normal interval','proxy_coefficient':coef,
              'min_audit_probability':float(p.min()),'expected_test_audits':float(p.sum())}
    labels=count*k+(calY.size if name in CALIBRATED else 0)
    queries=judge_cost+(calS.size if name in CALIBRATED else 0)
    costs=labels*rho+queries
    return choice,{'cost':costs,'audit_labels':labels,'judge_queries':np.full(seeds,queries)},meta


def attack_candidates(cube,Y,kcap,seed,answers):
    cache_key=(cube.tobytes(),Y.tobytes(),answers.tobytes(),kcap,seed)
    if cache_key in _ATTACK_POOL:return _ATTACK_POOL[cache_key]
    n,k=Y.shape;clean=cube[0];hi=cube.argmax(axis=0);lo=cube.argmin(axis=0)
    high=cube.max(axis=0);low=cube.min(axis=0)
    result=[('no_edit',np.zeros((n,k),int))]
    worst=int(Y.mean(0).argmin());best=int(Y.mean(0).argmax())
    objectives=[]
    for target in range(k):
        for direction in [1,-1]:
            weight=np.zeros(k);weight[target]=direction
            objectives.append((f'arm{target}_dir{direction}',weight))
    w=np.full(k,-0.5);w[worst]=1;objectives.append(('promote_worst',w))
    w=np.zeros(k);w[best]=-1;w[0]+=1;objectives.append(('suppress_best',w))
    for name,w in objectives:
        modes=np.where(w[None,:]>=0,hi,lo)
        gain=np.abs(w)[None,:]*np.where(w[None,:]>=0,high-clean,clean-low)
        order=np.argsort(gain.ravel(),kind='stable')[::-1]
        for f in [.5,1.0]:
            mask=np.zeros((n,k),int);ix=order[:int(kcap*f)]
            mask.ravel()[ix]=modes.ravel()[ix]
            result.append((name+f'_fraction{f}',mask))
    # Maximize residual magnitude, exploiting overconfident proxy errors.
    errors=(cube-Y[None,:,:])**2
    mode=errors.argmax(axis=0);gain=errors.max(axis=0)-errors[0]
    mask=np.zeros((n,k),int);ix=np.argsort(gain.ravel())[::-1][:kcap];mask.ravel()[ix]=mode.ravel()[ix]
    result.append(('residual_variance',mask))
    rng=np.random.default_rng(seed)
    for t in range(4):
        mask=np.zeros((n,k),int);ix=rng.choice(n*k,kcap,replace=False)
        mask.ravel()[ix]=rng.integers(1,len(cube),len(ix));result.append((f'random_{t}',mask))
    # Exact top-k pairwise attacks on the *projected* judge, including known
    # missing-answer zeros and equality-class averaging. The raw-score recipes
    # alone waste edits on responses whose scores the defender ignores.
    for target in range(k):
      for opponent in range(k):
        if target==opponent:continue
        coeff=np.zeros_like(clean)
        for row in range(n):
          for value in np.unique(answers[row]):
            group=answers[row]==value
            if value!='None':coeff[row,group]=(int(group[target])-int(group[opponent]))/group.sum()
        gains=coeff[None,:,:]*(cube-clean[None,:,:])
        modes=gains.argmax(axis=0);best_gain=gains.max(axis=0)
        order=np.argsort(best_gain.ravel(),kind='stable')[::-1]
        for fraction in [.5,1.0]:
            mask=np.zeros((n,k),int);ix=order[:int(kcap*fraction)]
            mask.ravel()[ix]=modes.ravel()[ix]
            result.append((f'projected_pair_{target}_{opponent}_fraction{fraction}',mask))
    # A second projection-aware recipe raises the paired residual second
    # moment. Individual cell gains are exact at the clean point; simultaneous
    # edits may interact, so the final selector is still evaluated explicitly.
    residual=differences(Y)-differences(project_scores(clean,answers))
    gains=np.zeros_like(cube)
    for row in range(n):
      for col in range(k):
        value=answers[row,col]
        if value=='None':continue
        group=(answers[row]==value).astype(float)
        direction=(group[1:]-group[0])/group.sum()
        change=cube[:,row,col]-clean[row,col]
        gains[:,row,col]=-2*change*np.dot(residual[row],direction)+change**2*np.dot(direction,direction)
    modes=gains.argmax(axis=0);order=np.argsort(gains.max(axis=0).ravel(),kind='stable')[::-1]
    mask=np.zeros((n,k),int);ix=order[:kcap];mask.ravel()[ix]=modes.ravel()[ix]
    result.append(('projected_residual_variance',mask))
    # Exploratory stronger-budget study also includes exact three-way ranking
    # witnesses. The original 10% study keeps its frozen phase-two attack set.
    if kcap>int(.1*Y.size) and (ROOT/'minimum_rank_attacks.json').exists():
        for witness in json.loads((ROOT/'minimum_rank_attacks.json').read_text()):
            if 'mask' in witness and witness['edited_responses']<=kcap:
                result.append(('minimum_rank_'+witness['target'],np.array(witness['mask'],int)))
    unique=[];seen=set()
    for name,mask in result:
        key=mask.tobytes()
        if key not in seen:unique.append((name,mask));seen.add(key)
    _ATTACK_POOL[cache_key]=unique
    return unique


def attack(name,data,cap,rho,budget,seed=713,objective='utility',attack_fraction=.1):
    cube=data['test']['cube'];Y=data['test']['Y'];kcap=int(attack_fraction*Y.size)
    if name in ['retain','development_only','trusted_uniform','trusted_disagreement','trusted_dev_challenger']:
        return np.zeros_like(Y,dtype=int),{'search_evaluations':0,'reason':'decision independent of judge text'}
    candidates=attack_candidates(cube,Y,kcap,seed,data['test']['answers'])
    # Published PP-LUCB is computationally more expensive; evaluate the same
    # deterministic candidates, but do not claim exhaustive attack optimality.
    def loss(choice):
        result=summary(choice,Y)
        return (result['utility'],-result['harm']) if objective=='utility' else (-result['harm'],result['utility'])
    scores=[]
    for label,mask in candidates:
        S=apply_attack(cube,mask)
        choice,_,_=run_method(name,S,data,cap,rho,budget,128,991)
        scores.append(loss(choice))
    i=min(range(len(scores)),key=lambda j:scores[j]);mask=candidates[i][1].copy();best=scores[i]
    rng=np.random.default_rng(seed+19);evals=len(scores)
    # Refine placements using the actual final decision, never just judge ASR.
    for _ in range(12 if not name.startswith('pp_lucb') else 3):
        trial=mask.copy();occupied=np.flatnonzero(trial.ravel());empty=np.flatnonzero(trial.ravel()==0)
        if len(occupied):trial.ravel()[rng.choice(occupied)]=0
        if len(empty):trial.ravel()[rng.choice(empty)]=rng.integers(1,len(cube))
        choice,_,_=run_method(name,apply_attack(cube,trial),data,cap,rho,budget,128,991)
        value=loss(choice);evals+=1
        if value<best:mask,best=trial,value
    assert np.count_nonzero(mask)<=kcap
    return mask,{'search_evaluations':evals,'objective':objective,'search_loss':list(best),'initial_recipe':candidates[i][0],
                 'edited_responses':int(np.count_nonzero(mask)),'response_cap':kcap,
                 'max_suffix_tokens':128,'search_audit_seeds':128,'is_exact_worst_case':False}


def interval(choice,Y,family=504,alpha=.05):
    gains=Y.mean(0)-Y[:,0].mean();u=gains[choice];n=len(u)
    harmed=int((u<0).sum());a=alpha/(4*family)
    # One-sided exact binomial MC bound; conditional on a fixed held-out pool
    # and a frozen feasible attack, not a worst-case or population certificate.
    hu=1.0 if harmed==n else float(beta_dist.ppf(1-a,harmed+1,n-harmed))
    hl=0.0 if harmed==0 else float(beta_dist.ppf(a,harmed,n-harmed+1))
    width=np.sqrt(2*np.var(u,ddof=1)*np.log(3/a)/n)+3*np.ptp(gains)*np.log(3/a)/n
    return {'harm_lower':hl,'harm_upper':hu,'utility_lower':float(u.mean()-width),
            'utility_upper':float(u.mean()+width),'interval_family':family,
            'scope':'simultaneous Monte Carlo bounds conditional on this question pool and searched attack'}


def save_csv(path,rows):
    if not rows:return
    keys=sorted(set().union(*(r.keys() for r in rows)))
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--primary-only',action='store_true');ap.add_argument('--methods',nargs='+')
    ap.add_argument('--attack-fraction',type=float,default=.1)
    ap.add_argument('--output-dir',type=Path,default=ROOT)
    ap.add_argument('--audit-seed',type=int,default=202610197);args=ap.parse_args()
    output=(ROOT/args.output_dir).resolve();output.mkdir(exist_ok=True,parents=True)
    data=load_data();start=time.perf_counter()
    (output/'evaluation').mkdir(exist_ok=True)
    ratios=[20] if args.primary_only else [5,20,50]
    methods=args.methods or METHODS
    for rho in ratios:
      for b in [.1,.2,.4]:
       # A common total budget, including every calibrated method's burn-in.
       n,k=data['test']['Y'].shape;cal=data['calibration']['Y'].shape[0]
       cap=k*(n+cal)+rho*k*(cal+n*b)
       for method in methods:
        stem=f'{method}_rho{rho}_b{b}'
        path=output/'evaluation'/f'{stem}.json'
        if path.exists():continue
        mask,ameta=attack(method,data,cap,rho,b,attack_fraction=args.attack_fraction)
        harm_mask,hmeta=attack(method,data,cap,rho,b,objective='harm',attack_fraction=args.attack_fraction)
        rows=[];saved={}
        for scenario,S in [('clean',data['test']['cube'][0]),('adaptive',apply_attack(data['test']['cube'],mask)),
                           ('harm_adaptive',apply_attack(data['test']['cube'],harm_mask))]:
            choices,counts,meta=run_method(method,S,data,cap,rho,b,5000,args.audit_seed)
            row={'method':method,'rho':rho,'nominal_audit_fraction':b,'total_cost_cap':cap,
                 'scenario':scenario,**summary(choices,data['test']['Y']),**interval(choices,data['test']['Y']),
                 'mean_cost':float(np.mean(counts['cost'])),'max_realized_cost':float(np.max(counts['cost'])),
                 'mean_audit_labels':float(np.mean(counts['audit_labels'])),
                 'mean_judge_queries':float(np.mean(counts['judge_queries'])),'audit_replications':5000,
                 'final_audit_seed':args.audit_seed,'attack_fraction':args.attack_fraction}
            if 'expected_test_audits' in meta:
                cal_count=data['calibration']['Y'].size if method in CALIBRATED else 0
                row['expected_cost']=rho*(3*meta['expected_test_audits']+cal_count)+row['mean_judge_queries']
            elif method in EXACT or method in ['retain','judge_only']:
                row['expected_cost']=row['mean_cost']
            else:row['expected_cost']=row['mean_cost']
            rows.append(row);saved[scenario+'_choices']=choices
        path.write_text(json.dumps({'rows':rows,'attack':ameta,'harm_attack':hmeta,'plan':meta,
                                    'attack_mask':mask.tolist(),'harm_attack_mask':harm_mask.tolist()},indent=2)+'\n')
        np.savez_compressed(output/'evaluation'/f'{stem}.npz',**saved,attack_mask=mask,harm_attack_mask=harm_mask)
        print(json.dumps({'completed':stem,'adaptive':rows[-1],'elapsed_seconds':time.perf_counter()-start}),flush=True)
    allrows=[]
    for path in sorted((output/'evaluation').glob('*.json')):allrows+=json.loads(path.read_text())['rows']
    save_csv(output/'results.csv',allrows)
    gen=list(map(json.loads,(ROOT/'graded_generations.jsonl').read_text().splitlines()))
    modelrows=[]
    for split in ['development','calibration','test']:
      for name in data['systems']:
        rr=[r for r in gen if r['split']==split and r['system']==name]
        modelrows.append({'split':split,'system':name,'n':len(rr),'accuracy':np.mean([r['correct'] for r in rr]),
                          'parse_failure_rate':np.mean([r['parsed_answer'] is None for r in rr]),
                          'token_cap_rate':np.mean([r['hit_token_cap'] for r in rr]),
                          'mean_tokens':np.mean([r['generated_tokens'] for r in rr]),
                          'mean_seconds':np.mean([r['seconds'] for r in rr])})
    save_csv(output/'system_accuracy.csv',modelrows)
    (output/'evaluation_metadata.json').write_text(json.dumps({'seconds_this_run':time.perf_counter()-start,
        'result_rows':len(allrows),'model_data':data['metadata'],'systems':data['systems'],
        'test_gains':(data['test']['Y'].mean(0)-data['test']['Y'][:,0].mean()).tolist()},indent=2)+'\n')


if __name__=='__main__':main()
