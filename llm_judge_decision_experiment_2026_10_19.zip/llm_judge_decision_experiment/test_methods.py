import unittest
import itertools
import numpy as np
from scipy.stats import hypergeom
from grade import parse
from methods import hypergeom_bounds,normalize,normal_decisions,exact_decisions,geometric_plan,project_scores,answer_key,trusted_challenger


class Tests(unittest.TestCase):
    def test_equivalent_numeric_answer_keys(self):
        self.assertEqual(answer_key('4.00'),answer_key('4'))
        self.assertEqual(answer_key('-0.00'),answer_key('0'))
        self.assertEqual(answer_key('1000'),answer_key('1E+3'))
        self.assertEqual(answer_key(None),'None')

    def test_grading(self):
        self.assertEqual(str(parse('Final answer: It costs $1,250.')[0]),'1250')
        self.assertIsNone(parse('Final answer: 7:10 pm')[0])
        self.assertIsNone(parse('Final answer: 12 or 13')[0])

    def test_exact_coverage_exhaustive_small_populations(self):
        for N in range(2,14):
            for m in range(N+1):
                lo,hi=hypergeom_bounds(N,m,0.05)
                for total in range(N+1):
                    x=np.arange(m+1);prob=hypergeom.pmf(x,N,total,m)
                    self.assertLessEqual(prob[lo>total].sum(),0.05+1e-12)
                    self.assertLessEqual(prob[hi<total].sum(),0.05+1e-12)

    def test_budget_and_geometric_endpoints(self):
        for b in [.1,.2,.4]:
            p=normalize(np.geomspace(1e-8,1,100),b)
            self.assertAlmostEqual(p.mean(),b,places=9)
            self.assertGreaterEqual(p.min(),0.05)
            p,meta=geometric_plan(np.ones((100,2)),b,c=1)
            self.assertAlmostEqual(p.mean(),b,places=9)

    def test_unobserved_labels_cannot_change_normal_decision(self):
        rng=np.random.default_rng(12);s=rng.random((40,3));y=rng.integers(0,2,(40,3)).astype(float)
        coins=rng.random((1,40));p=np.full(40,.3)
        out=normal_decisions(s,y,p,1,coins)
        alternate=y.copy();alternate[coins[0]>=p]=1-alternate[coins[0]>=p]
        other=normal_decisions(s,alternate,p,1,coins)
        np.testing.assert_array_equal(out[0],other[0]);np.testing.assert_allclose(out[2],other[2])

    def test_census_is_exact_and_agreement_free(self):
        rng=np.random.default_rng(5);s=rng.random((20,3));y=rng.integers(0,2,(20,3)).astype(float)
        ans=np.array([[f'{i}-{j}' for j in range(3)] for i in range(20)])
        keys=rng.random((5,20));choice,cost,lo=exact_decisions(s,y,ans,20,keys,'trusted_uniform')
        np.testing.assert_allclose(lo,np.tile((y[:,1:]-y[:,[0]]).mean(0),(5,1)))
        self.assertTrue(np.all(cost==20))
        ans[:]=ans[:,[0]];y[:]=y[:,[0]]
        choice,cost,lo=exact_decisions(s,y,ans,10,keys,'trusted_disagreement')
        self.assertTrue(np.all(choice==0));self.assertTrue(np.all(cost==0))

    def test_score_projection_uses_only_answer_equivalence(self):
        answers=np.array([['4','4','None'],['None','8','9']])
        scores=np.array([[.9,.1,.8],[.7,.2,.8]])
        np.testing.assert_allclose(project_scores(scores,answers),[[.5,.5,0],[0,.2,.8]])
        np.testing.assert_array_equal(scores,[[.9,.1,.8],[.7,.2,.8]])

    def test_exact_support_bounds_with_missing_and_equal_answers(self):
        answers=np.array([['1','1','9'],['2','None','2'],['9','3','3'],
                          ['4','9','None'],['None','9','5'],['6','9','6']])
        truth=np.array(['1','2','3','4','5','6'])
        y=(answers==truth[:,None]).astype(float)
        gap=(y[:,1:]-y[:,[0]]).mean(0)
        for m in range(7):
            subsets=list(itertools.combinations(range(6),m))
            keys=np.ones((len(subsets),6))
            for row,sub in enumerate(subsets):keys[row,list(sub)]=0
            _,_,lo=exact_decisions(np.full((6,3),.5),y,answers,m,keys,'trusted_uniform',alpha=.1)
            self.assertLessEqual(np.mean(np.any(lo>gap[None,:]+1e-12,axis=1)),.1+1e-12)

    def test_development_challenger_exact_coverage(self):
        answers=np.array([['1','1'],['2','None'],['9','3'],['4','9'],['None','9'],['6','9']])
        truth=np.array(['1','2','3','4','5','6']);y=(answers==truth[:,None]).astype(float)
        group=np.flatnonzero(answers[:,0]!=answers[:,1]);gap=(y[:,1]-y[:,0]).mean()
        for m in range(len(group)+1):
            subsets=list(itertools.combinations(group,m));keys=np.ones((len(subsets),6))
            for row,sub in enumerate(subsets):keys[row,list(sub)]=0
            chosen,count,lo=trusted_challenger(y,answers,m,keys,1,alpha=.1)
            self.assertLessEqual(np.mean(lo>gap+1e-12),.1+1e-12)
            self.assertTrue(np.all(count==m))


if __name__=='__main__':unittest.main()
